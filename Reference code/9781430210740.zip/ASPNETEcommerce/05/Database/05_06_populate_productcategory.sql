USE BalloonShop
GO

INSERT INTO ProductCategory(ProductID, CategoryID)		
VALUES(1, 1)
GO

INSERT INTO ProductCategory(ProductID, CategoryID)		
VALUES(1, 2)
GO

INSERT INTO ProductCategory(ProductID, CategoryID)		
VALUES(2, 1)
GO

INSERT INTO ProductCategory(ProductID, CategoryID)		
VALUES(2, 4)
GO

INSERT INTO ProductCategory(ProductID, CategoryID)		
VALUES(2, 6)
GO

INSERT INTO ProductCategory(ProductID, CategoryID)		
VALUES(3, 1)
GO

INSERT INTO ProductCategory(ProductID, CategoryID)		
VALUES(3, 3)
GO

INSERT INTO ProductCategory(ProductID, CategoryID)		
VALUES(3, 4)
GO

INSERT INTO ProductCategory(ProductID, CategoryID)		
VALUES(4, 1)
GO

INSERT INTO ProductCategory(ProductID, CategoryID)		
VALUES(4, 2)
GO

INSERT INTO ProductCategory(ProductID, CategoryID)		
VALUES(4, 4)
GO

INSERT INTO ProductCategory(ProductID, CategoryID)		
VALUES(4, 6)
GO

INSERT INTO ProductCategory(ProductID, CategoryID)		
VALUES(5, 1)
GO

INSERT INTO ProductCategory(ProductID, CategoryID)		
VALUES(6, 1)
GO

INSERT INTO ProductCategory(ProductID, CategoryID)		
VALUES(6, 3)
GO

INSERT INTO ProductCategory(ProductID, CategoryID)		
VALUES(6, 4)
GO

INSERT INTO ProductCategory(ProductID, CategoryID)		
VALUES(7, 1)
GO

INSERT INTO ProductCategory(ProductID, CategoryID)		
VALUES(8, 1)
GO

INSERT INTO ProductCategory(ProductID, CategoryID)		
VALUES(9, 1)
GO

INSERT INTO ProductCategory(ProductID, CategoryID)		
VALUES(10, 1)
GO

INSERT INTO ProductCategory(ProductID, CategoryID)		
VALUES(11, 1)
GO

INSERT INTO ProductCategory(ProductID, CategoryID)		
VALUES(12, 1)
GO

INSERT INTO ProductCategory(ProductID, CategoryID)		
VALUES(12, 4)
GO

INSERT INTO ProductCategory(ProductID, CategoryID)		
VALUES(13, 1)
GO

INSERT INTO ProductCategory(ProductID, CategoryID)		
VALUES(13, 4)
GO

INSERT INTO ProductCategory(ProductID, CategoryID)		
VALUES(14, 1)
GO

INSERT INTO ProductCategory(ProductID, CategoryID)		
VALUES(14, 4)
GO

INSERT INTO ProductCategory(ProductID, CategoryID)		
VALUES(15, 1)
GO

INSERT INTO ProductCategory(ProductID, CategoryID)		
VALUES(16, 1)
GO

INSERT INTO ProductCategory(ProductID, CategoryID)		
VALUES(16, 4)
GO

INSERT INTO ProductCategory(ProductID, CategoryID)		
VALUES(17, 1)
GO

INSERT INTO ProductCategory(ProductID, CategoryID)		
VALUES(17, 4)
GO

INSERT INTO ProductCategory(ProductID, CategoryID)		
VALUES(18, 1)
GO

INSERT INTO ProductCategory(ProductID, CategoryID)		
VALUES(18, 4)
GO

INSERT INTO ProductCategory(ProductID, CategoryID)		
VALUES(19, 1)
GO

INSERT INTO ProductCategory(ProductID, CategoryID)		
VALUES(19, 4)
GO

INSERT INTO ProductCategory(ProductID, CategoryID)		
VALUES(19, 6)
GO

INSERT INTO ProductCategory(ProductID, CategoryID)		
VALUES(20, 1)
GO

INSERT INTO ProductCategory(ProductID, CategoryID)		
VALUES(20, 4)
GO

INSERT INTO ProductCategory(ProductID, CategoryID)		
VALUES(21, 4)
GO

INSERT INTO ProductCategory(ProductID, CategoryID)		
VALUES(21, 5)
GO

INSERT INTO ProductCategory(ProductID, CategoryID)		
VALUES(21, 6)
GO

INSERT INTO ProductCategory(ProductID, CategoryID)		
VALUES(22, 2)
GO

INSERT INTO ProductCategory(ProductID, CategoryID)		
VALUES(22, 4)
GO

INSERT INTO ProductCategory(ProductID, CategoryID)		
VALUES(23, 2)
GO

INSERT INTO ProductCategory(ProductID, CategoryID)		
VALUES(23, 4)
GO

INSERT INTO ProductCategory(ProductID, CategoryID)		
VALUES(24, 2)
GO

INSERT INTO ProductCategory(ProductID, CategoryID)		
VALUES(25, 5)
GO

INSERT INTO ProductCategory(ProductID, CategoryID)		
VALUES(26, 1)
GO

INSERT INTO ProductCategory(ProductID, CategoryID)		
VALUES(26, 4)
GO

INSERT INTO ProductCategory(ProductID, CategoryID)		
VALUES(28, 2)
GO

INSERT INTO ProductCategory(ProductID, CategoryID)		
VALUES(28, 4)
GO

INSERT INTO ProductCategory(ProductID, CategoryID)		
VALUES(28, 6)
GO

INSERT INTO ProductCategory(ProductID, CategoryID)		
VALUES(29, 4)
GO

INSERT INTO ProductCategory(ProductID, CategoryID)		
VALUES(30, 4)
GO

INSERT INTO ProductCategory(ProductID, CategoryID)		
VALUES(30, 6)
GO

INSERT INTO ProductCategory(ProductID, CategoryID)		
VALUES(31, 4)
GO

INSERT INTO ProductCategory(ProductID, CategoryID)		
VALUES(32, 4)
GO

INSERT INTO ProductCategory(ProductID, CategoryID)		
VALUES(33, 4)
GO

INSERT INTO ProductCategory(ProductID, CategoryID)		
VALUES(34, 4)
GO

INSERT INTO ProductCategory(ProductID, CategoryID)		
VALUES(35, 4)
GO

INSERT INTO ProductCategory(ProductID, CategoryID)		
VALUES(36, 4)
GO

INSERT INTO ProductCategory(ProductID, CategoryID)		
VALUES(37, 4)
GO

INSERT INTO ProductCategory(ProductID, CategoryID)		
VALUES(37, 6)
GO

INSERT INTO ProductCategory(ProductID, CategoryID)		
VALUES(38, 4)
GO

INSERT INTO ProductCategory(ProductID, CategoryID)		
VALUES(38, 6)
GO

INSERT INTO ProductCategory(ProductID, CategoryID)		
VALUES(39, 5)
GO

INSERT INTO ProductCategory(ProductID, CategoryID)		
VALUES(40, 5)
GO

INSERT INTO ProductCategory(ProductID, CategoryID)		
VALUES(41, 5)
GO

INSERT INTO ProductCategory(ProductID, CategoryID)		
VALUES(42, 5)
GO

INSERT INTO ProductCategory(ProductID, CategoryID)		
VALUES(43, 5)
GO

INSERT INTO ProductCategory(ProductID, CategoryID)		
VALUES(44, 5)
GO

INSERT INTO ProductCategory(ProductID, CategoryID)		
VALUES(45, 5)
GO

INSERT INTO ProductCategory(ProductID, CategoryID)		
VALUES(46, 5)
GO

INSERT INTO ProductCategory(ProductID, CategoryID)		
VALUES(47, 5)
GO

INSERT INTO ProductCategory(ProductID, CategoryID)		
VALUES(48, 5)
GO

INSERT INTO ProductCategory(ProductID, CategoryID)		
VALUES(49, 5)
GO

INSERT INTO ProductCategory(ProductID, CategoryID)		
VALUES(50, 5)
GO

INSERT INTO ProductCategory(ProductID, CategoryID)		
VALUES(51, 5)
GO

INSERT INTO ProductCategory(ProductID, CategoryID)		
VALUES(52, 6)
GO

INSERT INTO ProductCategory(ProductID, CategoryID)		
VALUES(53, 5)
GO

INSERT INTO ProductCategory(ProductID, CategoryID)		
VALUES(53, 6)
GO

INSERT INTO ProductCategory(ProductID, CategoryID)		
VALUES(54, 5)
GO

INSERT INTO ProductCategory(ProductID, CategoryID)		
VALUES(54, 6)
GO

INSERT INTO ProductCategory(ProductID, CategoryID)		
VALUES(55, 5)
GO

INSERT INTO ProductCategory(ProductID, CategoryID)		
VALUES(55, 6)
GO

INSERT INTO ProductCategory(ProductID, CategoryID)		
VALUES(56, 3)
GO

INSERT INTO ProductCategory(ProductID, CategoryID)		
VALUES(57, 1)
GO

INSERT INTO ProductCategory(ProductID, CategoryID)		
VALUES(57, 2)
GO

INSERT INTO ProductCategory(ProductID, CategoryID)		
VALUES(57, 3)
GO

INSERT INTO ProductCategory(ProductID, CategoryID)		
VALUES(58, 1)
GO

INSERT INTO ProductCategory(ProductID, CategoryID)		
VALUES(58, 2)
GO

INSERT INTO ProductCategory(ProductID, CategoryID)		
VALUES(58, 3)
GO

INSERT INTO ProductCategory(ProductID, CategoryID)		
VALUES(59, 1)
GO

INSERT INTO ProductCategory(ProductID, CategoryID)		
VALUES(59, 2)
GO

INSERT INTO ProductCategory(ProductID, CategoryID)		
VALUES(59, 3)
GO

INSERT INTO ProductCategory(ProductID, CategoryID)		
VALUES(60, 1)
GO

INSERT INTO ProductCategory(ProductID, CategoryID)		
VALUES(60, 2)
GO

INSERT INTO ProductCategory(ProductID, CategoryID)		
VALUES(60, 3)
GO

INSERT INTO ProductCategory(ProductID, CategoryID)		
VALUES(61, 1)
GO

INSERT INTO ProductCategory(ProductID, CategoryID)		
VALUES(61, 3)
GO

INSERT INTO ProductCategory(ProductID, CategoryID)		
VALUES(62, 1)
GO

INSERT INTO ProductCategory(ProductID, CategoryID)		
VALUES(62, 3)
GO
