USE BalloonShop

GO

INSERT INTO Department(Name, Description)		
VALUES ('Anniversary Balloons', 'These sweet balloons are the perfect gift for someone you love.')

GO

INSERT INTO Department(Name, Description )		
VALUES ('Balloons for Children', 'The colorful and funny balloons will make any child smile!')

GO


