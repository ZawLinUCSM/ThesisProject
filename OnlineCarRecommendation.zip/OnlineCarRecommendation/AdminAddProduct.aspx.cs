﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

public partial class AdminAddProduct : System.Web.UI.Page
{
    #region Page_Load
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {// Fill Controls with data
            PopulateControls();

        }
    }
    #endregion

    #region Member Methods


    private void PopulateControls()
    {
        // Populate all Attribute Data
        PopulateBrandAttribute();

        PopulateYearAttribute();

        PopulatePrice();

        PopulateMilage();

        PopulateModel();

        PopulateHandDrive();

        PopulateEnginePower();

        PopulateFuel();

        PopulateDoors();

        PopulateSeats();

        PopulateColor();

        PopulateTypeOfCar();
    }

    // Retrieve Brand data from the database
    private void PopulateBrandAttribute()
    {
        DataTable brandTable = ProductAccess.GetBrand();
        string brandid, brandname;

        for (int i = 0; i < brandTable.Rows.Count; i++)
        {
            // obtain brand id and name
            brandid = brandTable.Rows[i]["BrandID"].ToString();
            brandname = brandTable.Rows[i]["BrandName"].ToString();

            // Add to brandList combo box
            brandList.Items.Add(new ListItem(brandname, brandid));

        }
        brandList.SelectedIndex = -1;

    }

    private void PopulateYearAttribute()
    {
        DataTable yearTable = ProductAccess.GetYear();
        string id, year;

        for (int i = 0; i < yearTable.Rows.Count; i++)
        {
            id = yearTable.Rows[i]["YearID"].ToString();
            year = yearTable.Rows[i]["Year"].ToString();

            yearLIst.Items.Add(new ListItem(year, id));

        }
    }

    private void PopulateModel()
    {
        DataTable modelTable = ProductAccess.GetModel();
        string id, model;

        for (int i = 0; i < modelTable.Rows.Count; i++)
        {
            id = modelTable.Rows[i]["ModelID"].ToString();
            model = modelTable.Rows[i]["ModelName"].ToString();

            modelList.Items.Add(new ListItem(model, id));
        }
    }

    private void PopulateTypeOfCar()
    {
        DataTable carTypeTable = ProductAccess.GetTypeOfCar();
        string id, type;

        for (int i = 0; i < carTypeTable.Rows.Count; i++)
        {
            id = carTypeTable.Rows[i]["TypeID"].ToString();
            type = carTypeTable.Rows[i]["TypeName"].ToString();


            typeList.Items.Add(new ListItem(type, id));
        }
    }

    private void PopulatePrice()
    {
        DataTable priceTable = ProductAccess.GetPrice();
        string id, price;

        for (int i = 0; i < priceTable.Rows.Count; i++)
        {
            id = priceTable.Rows[i]["PriceID"].ToString();
            price = priceTable.Rows[i]["Price"].ToString();

            priceList.Items.Add(new ListItem(price, id));

        }
    }

    private void PopulateColor()
    {
        DataTable colorTable = ProductAccess.GetColor();
        string id, color;

        for (int i = 0; i < colorTable.Rows.Count; i++)
        {
            id = colorTable.Rows[i]["ColorID"].ToString();
            color = colorTable.Rows[i]["ColorName"].ToString();

            colorList.Items.Add(new ListItem(color, id));

        }

    }

    private void PopulateFuel()
    {
        DataTable fuelTable = ProductAccess.GetFuel();
        string id, fuelname;

        for (int i = 0; i < fuelTable.Rows.Count; i++)
        {
            id = fuelTable.Rows[i]["FuelID"].ToString();
            fuelname = fuelTable.Rows[i]["FuelName"].ToString();

            fuelList.Items.Add(new ListItem(fuelname, id));
        }

    }

    private void PopulateEnginePower()
    {
        DataTable engineTable = ProductAccess.GetEnginePower();
        string id, name;

        for (int i = 0; i < engineTable.Rows.Count; i++)
        {
            id = engineTable.Rows[i]["EnginePowerID"].ToString();
            name = engineTable.Rows[i]["EngineName"].ToString();

            engineList.Items.Add(new ListItem(name, id));
        }
    }

    private void PopulateHandDrive()
    {
        DataTable tableHand = ProductAccess.GetHandDrive();
        string id, name;

        for (int i = 0; i < tableHand.Rows.Count; i++)
        {
            id = tableHand.Rows[i]["HandDriveID"].ToString();
            name = tableHand.Rows[i]["HandDriveName"].ToString();

            handList.Items.Add(new ListItem(name, id));

        }
    }

    private void PopulateMilage()
    {
        DataTable tableMilage = ProductAccess.GetMilage();
        string id, milage;

        for (int i = 0; i < tableMilage.Rows.Count; i++)
        {
            id = tableMilage.Rows[i]["MilageID"].ToString();
            milage = tableMilage.Rows[i]["Milage"].ToString();

            mileslist.Items.Add(new ListItem(milage, id));

        }
    }


    private void PopulateDoors()
    {
        DataTable tableDoors = ProductAccess.GetDoors();
        string id, doors;

        for (int i = 0; i < tableDoors.Rows.Count; i++)
        {
            id = tableDoors.Rows[i]["DoorID"].ToString();
            doors = tableDoors.Rows[i]["DoorQty"].ToString();

            doorList.Items.Add(new ListItem(doors, id));

        }
    }

    private void PopulateSeats()
    {
        DataTable tableSeats = ProductAccess.GetSeat();
        string id, seats;

        for (int i = 0; i < tableSeats.Rows.Count; i++)
        {
            id = tableSeats.Rows[i]["SeatID"].ToString();
            seats = tableSeats.Rows[i]["SeatQty"].ToString();

            seatList.Items.Add(new ListItem(seats, id));
        }
    }

    private bool ValidateEntry()
    {
        if (brandList.SelectedItem.Value.ToString() == "")
        {
            statusLabel.Text = "Please Select Brand !";
            brandList.Focus();
            return false;
        }
        if (yearLIst.SelectedItem.Value.ToString() == "")
        {
            statusLabel.Text = "Please Select Year !";
            yearLIst.Focus();
            return false;

        }

        if (modelList.SelectedItem.Value.ToString() == "")
        {
            statusLabel.Text = "Please Select Model !";
            modelList.Focus();
            return false;

        }

        if (typeList.SelectedItem.Value.ToString() == "")
        {
            statusLabel.Text = "Please Select Type of Car !";
            typeList.Focus();
            return false;

        }

        if (priceList.SelectedItem.Value.ToString() == "")
        {
            statusLabel.Text = "Please Select Price !";
            priceList.Focus();
            return false;

        }
        if (colorList.SelectedItem.Value.ToString() == "")
        {
            statusLabel.Text = "Please Select Color !";
            colorList.Focus();
            return false;

        }

        if (fuelList.SelectedItem.Value.ToString() == "")
        {
            statusLabel.Text = "Please Select Fuel Type !";
            fuelList.Focus();
            return false;

        }

        if (engineList.SelectedItem.Value.ToString() == "")
        {
            statusLabel.Text = "Please Select Engine Power !";
            engineList.Focus();
            return false;

        }

        if (handList.SelectedItem.Value.ToString() == "")
        {
            statusLabel.Text = "Please Select HandDrive!";
            handList.Focus();
            return false;

        }

        if (mileslist.SelectedItem.Value.ToString() == "")
        {
            statusLabel.Text = "Please Select Miles!";
            mileslist.Focus();
            return false;

        }

        if (doorList.SelectedItem.Value.ToString() == "")
        {
            statusLabel.Text = "Please Select Doors!";
            doorList.Focus();
            return false;

        }

        if (seatList.SelectedItem.Value.ToString() == "")
        {
            statusLabel.Text = "Please Select Seats !";
            seatList.Focus();
            return false;

        }
        if (newDescription.Text == "")
        {
            statusLabel.Text = "Please Enter Description !";
            newDescription.Focus();
            return false;

        }

        //if (image1FileUpload.FileName == "")
        //{
        //    statusLabel.Text = "Please Browse Thumbnail File And Upload!";
        //    return false;
        //}
        //if (image2FileUpload.FileName == "")
        //{
        //    statusLabel.Text = "Please Browse Image File and Upload";
        //    return false;

        //}
        return true;
    }

    private void SaveNewProduct()
    {
        if (!ValidateEntry())
        {
            return;
        }

        string brandID = brandList.SelectedItem.Value.ToString();
        string yearID = yearLIst.SelectedItem.Value.ToString();
        string modelID = modelList.SelectedItem.Value.ToString();
        string typeID = typeList.SelectedItem.Value.ToString();
        string priceID = priceList.SelectedItem.Value.ToString();
        string colorID = colorList.SelectedItem.Value.ToString();
        string fuelID = fuelList.SelectedItem.Value.ToString();
        string engineID = engineList.SelectedItem.Value.ToString();
        string handID = handList.SelectedItem.Value.ToString();
        string mileID = mileslist.SelectedItem.Value.ToString();
        string doorID = doorList.SelectedItem.Value.ToString();
        string seatID = seatList.SelectedItem.Value.ToString();

        string description = newDescription.Text.ToString();
        string thumbnail = image1FileUpload.FileName;
        string image = image2FileUpload.FileName;



        // Get Price From PriceID
        string pric = GetPrice(priceID);

        // Get Brand From BrandID
        string brand = GetBrand(brandID);

        // Get Model From ModelID
        string model = GetModel(modelID);

        decimal price = Convert.ToDecimal(pric);
        string name = brand + " " + model;
        bool success = ProductAccess.CreateProduct(brandID, yearID, modelID, typeID, priceID, colorID, fuelID, engineID, handID, mileID, doorID, seatID, description, thumbnail, image, price, name);

        statusLabel.Text = success ? "Insert Successful" : "Insert Failed";

    }

    private string GetModel(string modelID)
    {
        DataTable modelTable = ProductAccess.GetModel(modelID);
        string model = "";

        if (modelTable.Rows.Count > 0)
        {
            model = modelTable.Rows[0]["ModelName"].ToString();
        }


        return model;
    }

    private string GetBrand(string brandID)
    {
        DataTable brandTable = ProductAccess.GetBrand(brandID);
        string brand = "";

        if (brandTable.Rows.Count > 0)
        {
            brand = brandTable.Rows[0]["BrandName"].ToString();

        }

        return brand;
    }

    private string GetPrice(string priceID)
    {
        DataTable priceTable = ProductAccess.GetPrice(priceID);
        string price = "";

        if (priceTable.Rows.Count > 0)
        {
            price = priceTable.Rows[0]["Price"].ToString();
        }

        return price;
    }

    #endregion

    #region Events

    // upload product's first image
    protected void upload1Button_Click(object sender, EventArgs e)
    {
        // proceed with uploading only if the user selected a file
        if (image1FileUpload.HasFile)
        {
            try
            {
                string fileName = image1FileUpload.FileName;
                string location = Server.MapPath("./ProductImages/") + fileName;

                // save image to server
                image1FileUpload.SaveAs(location);
            }
            catch
            {

                statusLabel.Text = "Uploading image 1 Failed";
            }

        }

    }

    protected void upload2Button_Click(object sender, EventArgs e)
    {
        if (image2FileUpload.HasFile)
        {
            try
            {
                string fileName = image2FileUpload.FileName;
                string location = Server.MapPath("./ProductImages/") + fileName;
                // save to image to server
                image2FileUpload.SaveAs(location);
            }
            catch
            {
                statusLabel.Text = "Uploading image 2 Failed";

            }
        }
    }

    protected void createProduct_Click(object sender, EventArgs e)
    {
        SaveNewProduct();
    }


    #endregion
}