﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

public partial class AdminFuel : System.Web.UI.Page
{
    #region Page_Load
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            BindGrid();

        }
    }
    #endregion

    #region Member Methods
    private void BindGrid()
    {
        grid.DataSource = ProductAccess.GetFuel();
        grid.DataBind();
    }
    #endregion

    #region Events
    protected void createfuel_Click(object sender, EventArgs e)
    {
        DataTable table = ProductAccess.GetFuel();
        if (table.Rows.Count >= 3)
        {
            return;
        }
        else
        {
            bool success = ProductAccess.CreateFuel(newFuel.Text);

            statusLabel.Text = success ? "Insert Successful" : "Insert Failed";

            BindGrid();
        }

    }
    #endregion
}