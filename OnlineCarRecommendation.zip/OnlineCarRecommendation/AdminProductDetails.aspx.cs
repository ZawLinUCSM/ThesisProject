﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

public partial class AdminProductDetails : System.Web.UI.Page
{
    #region Variables
    // store the current product ID;
    string currentProductId;
    #endregion

    #region Page_Load

    protected void Page_Load(object sender, EventArgs e)
    {

        currentProductId = Request.QueryString["ProductID"];

        // fill the controls with data in the initial page loaded
        if (!Page.IsPostBack)
        {
            //Pupulate Controls
            if (currentProductId != null)
            {
                PopulateControls();
            }


        }
    }

    #endregion

    #region Member Methods

    // Populate controls and fill with data from the database
    // for all attributes and details
    private void PopulateControls()
    {
        PopulateBrandWithProduct();
        PopulateYearWithProduct();
        PopulateModelWithProduct();
        PopulateTypeWithProduct();
        PopulatePriceWithProduct();
        PopulateColorWithProduct();
        PopulateEnginePowerWithProduct();
        PopulateFuelWithProduct();
        PopulateHandDriveWithProduct();
        PopulateMilageWithProduct();
        PopulateDoorWithProduct();
        PopulateSeatWithProduct();
        PopulateDescriptionAndOthers();
    }

    private void PopulateBrandWithProduct()
    {
        DataTable tableBrand = ProductAccess.GetBrandWithProduct(currentProductId);

        for (int i = 0; i < tableBrand.Rows.Count; i++)
        {
            string id = tableBrand.Rows[i]["BrandID"].ToString();
            string name = tableBrand.Rows[i]["BrandName"].ToString();

            brandList.Items.Add(new ListItem(name, id));

        }
    }

    private void PopulateYearWithProduct()
    {
        DataTable tableYear = ProductAccess.GetYearWithProduct(currentProductId);

        string id, name;
        for (int i = 0; i < tableYear.Rows.Count; i++)
        {
            id = tableYear.Rows[i]["YearID"].ToString();
            name = tableYear.Rows[i]["Year"].ToString();

            yearLIst.Items.Add(new ListItem(name, id));

        }
    }

    private void PopulateModelWithProduct()
    {
        DataTable tableModel = ProductAccess.GetModelWithProduct(currentProductId);

        string id, name;
        for (int i = 0; i < tableModel.Rows.Count; i++)
        {
            id = tableModel.Rows[i]["ModelID"].ToString();
            name = tableModel.Rows[i]["ModelName"].ToString();

            modelList.Items.Add(new ListItem(name, id));

        }
    }

    private void PopulateTypeWithProduct()
    {
        DataTable tableType = ProductAccess.GetTypeWithProduct(currentProductId);

        string id, name;
        for (int i = 0; i < tableType.Rows.Count; i++)
        {
            id = tableType.Rows[i]["TypeID"].ToString();
            name = tableType.Rows[i]["TypeName"].ToString();

            typeList.Items.Add(new ListItem(name, id));
        }
    }

    private void PopulatePriceWithProduct()
    {
        DataTable tablePrice = ProductAccess.GetPriceWithProduct(currentProductId);

        string id, name;
        for (int i = 0; i < tablePrice.Rows.Count; i++)
        {
            id = tablePrice.Rows[i]["PriceID"].ToString();
            name = tablePrice.Rows[i]["Price"].ToString();

            priceList.Items.Add(new ListItem(name, id));

        }
    }

    private void PopulateColorWithProduct()
    {
        DataTable tableColor = ProductAccess.GetColorWithProduct(currentProductId);
        string id, name;

        for (int i = 0; i < tableColor.Rows.Count; i++)
        {
            id = tableColor.Rows[i]["ColorID"].ToString();
            name = tableColor.Rows[i]["ColorName"].ToString();

            colorList.Items.Add(new ListItem(name, id));

        }
    }

    private void PopulateFuelWithProduct()
    {
        DataTable tableFuel = ProductAccess.GetFuelWithProduct(currentProductId);
        string id, name;
        for (int i = 0; i < tableFuel.Rows.Count; i++)
        {
            id = tableFuel.Rows[i]["FuelID"].ToString();
            name = tableFuel.Rows[i]["FuelName"].ToString();

            fuelList.Items.Add(new ListItem(name, id));

        }
    }

    private void PopulateEnginePowerWithProduct()
    {
        DataTable tableEnginePower = ProductAccess.GetEnginePowerWithProduct(currentProductId);
        string id, name;

        for (int i = 0; i < tableEnginePower.Rows.Count; i++)
        {
            id = tableEnginePower.Rows[i]["EnginePowerID"].ToString();
            name = tableEnginePower.Rows[i]["EngineName"].ToString();

            engineList.Items.Add(new ListItem(name, id));

        }
    }

    private void PopulateHandDriveWithProduct()
    {
        DataTable tableHandDrive = ProductAccess.GetHandDriveWithProduct(currentProductId);
        string id, name;
        for (int i = 0; i < tableHandDrive.Rows.Count; i++)
        {
            id = tableHandDrive.Rows[i]["HandDriveID"].ToString();
            name = tableHandDrive.Rows[i]["HandDriveName"].ToString();

            handList.Items.Add(new ListItem(name, id));

        }
    }

    private void PopulateMilageWithProduct()
    {
        DataTable tableMilage = ProductAccess.GetMilageWithProduct(currentProductId);
        string id, name;

        for (int i = 0; i < tableMilage.Rows.Count; i++)
        {
            id = tableMilage.Rows[i]["MilageID"].ToString();
            name = tableMilage.Rows[i]["Milage"].ToString();

            mileslist.Items.Add(new ListItem(name, id));
        }
    }

    private void PopulateDoorWithProduct()
    {
        DataTable tableDoor = ProductAccess.GetDoorWithProduct(currentProductId);
        string id, name;

        for (int i = 0; i < tableDoor.Rows.Count; i++)
        {
            id = tableDoor.Rows[i]["DoorID"].ToString();
            name = tableDoor.Rows[i]["DoorQty"].ToString();

            doorList.Items.Add(new ListItem(name, id));
        }

    }

    private void PopulateSeatWithProduct()
    {
        DataTable tableSeat = ProductAccess.GetSeatWithProduct(currentProductId);
        string id, name;

        for (int i = 0; i < tableSeat.Rows.Count; i++)
        {
            id = tableSeat.Rows[i]["SeatID"].ToString();
            name = tableSeat.Rows[i]["SeatQty"].ToString();

            seatList.Items.Add(new ListItem(name, id));
        }
    }

    private void PopulateDescriptionAndOthers()
    {
        DataTable tableDescription = ProductAccess.GetProductDescriptionAndOthers(currentProductId);
        string desc, thumbnail, image;

        for (int i = 0; i < tableDescription.Rows.Count; i++)
        {
            desc = tableDescription.Rows[i]["Description"].ToString();
            thumbnail = tableDescription.Rows[i]["Thumbnail"].ToString();
            image = tableDescription.Rows[i]["Image"].ToString();

            newDescription.Text = desc;
            Image1Label.Text = thumbnail;
            Image2Label.Text = image;
        }


    }

    #endregion
}