﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class AdminMilage : System.Web.UI.Page
{
    #region Page_Load
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            BindGrid();

        }
    }

    #endregion

    #region Member Methods
    private void BindGrid()
    {
        grid.DataSource = ProductAccess.GetMilage();
        grid.DataBind();
    }
    #endregion

    #region Events
    protected void createmile_Click(object sender, EventArgs e)
    {
        bool success = ProductAccess.CreateMilage(Convert.ToInt32(newMilage.Text));

        statusLabel.Text = success ? "Insert Successful" : "Insert Failed";

        BindGrid();
    }
    #endregion
}