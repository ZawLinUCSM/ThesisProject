﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class AdminEnginePower : System.Web.UI.Page
{
    #region Page_Load
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            BindGrid();

        }
    }

    #endregion

    #region Member Methods
    private void BindGrid()
    {
        grid.DataSource = ProductAccess.GetEnginePower();
        grid.DataBind();
    }
    #endregion

    #region Events
    protected void createEngine_Click(object sender, EventArgs e)
    {
        bool success = ProductAccess.CreateEnginePower(newName.Text+"  Cc");

        statusLabel.Text = success ? "Insert Successful" : "Insert Failed";

        BindGrid();

    }

    #endregion

}