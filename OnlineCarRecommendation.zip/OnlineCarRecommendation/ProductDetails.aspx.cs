﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Diagnostics;

public partial class ProductDetails : System.Web.UI.Page
{

    #region Page_Load

    protected void Page_Load(object sender, EventArgs e)
    {
        string currentProductID;
        string userID;
        if (!Page.IsPostBack)
        {
            if (Session["UserID"] != null && Session["UserName"] != null)
            {
                currentProductID = Request.QueryString["ProductID"];
                // Get User ID 
                userID = Session["UserID"].ToString();
                //string userID = OCRConfiguration.userID;

                // Get Product details with currentProductID
                ProductDetail pd = ProductAccess.GetProductDetailsWithProduct(currentProductID);

                if (pd.brand != null)
                {
                    PopulateControls(pd);
                }

                Stopwatch st = new Stopwatch();
                st.Start();
                // Call for user click stream data
                ProductClickStreamData(userID, currentProductID);
                st.Stop();
                string elapsedtime = st.Elapsed.TotalSeconds.ToString();
            }
        }


    }

    #endregion

    #region Member Methods
    private void ProductClickStreamData(string userID, string currentProductID)
    {
        // Call the function to store use click data
        if ((!string.IsNullOrEmpty(currentProductID)) && (!string.IsNullOrEmpty(userID)))
        {
            string _loginUserID = userID;
            // Get Product Details with productID
            ProductDetail pd = ProductAccess.GetProductDetailsWithProduct(currentProductID);


            Stopwatch sw = new Stopwatch();
            sw.Start();
            // Select ProductHistory list with current userid
            DataTable historytable = ProductAccess.GetProductHistoryByUserID(userID);

            sw.Stop();
            string searchTime = sw.Elapsed.TotalSeconds.ToString();

            // Check User click product is contain in history table
            bool isContain = historytable.AsEnumerable().Any(s => s.Field<Int32>("ProductID") == Convert.ToInt32(currentProductID));

            // if the user click product is not contain
            if (!isContain)
            {
                #region SaveClickProduct, Create User Profile, Calculate Similarity and Recommeandations

                // Save user click product details to ProductHistory table in Database
                ProductAccess.SaveClickProduct(pd.ProductId, userID, pd.brand, pd.year, pd.model, pd.type, pd.Price, pd.colorName, pd.fuel, pd.enginePowerName, pd.handDrive, pd.miles, pd.doorqty, pd.seatqty);

                DataTable loginUserTable = ProductAccess.GetProductHistoryByUserID(_loginUserID);
                //Create User Click Stream Data as 0 and 1
                ProductAccess.CreateUserClickData(loginUserTable, _loginUserID);

                //Create  User Profile for current user
                ProductAccess.CreateUserProfile(string.Empty, _loginUserID);

                // Get UserLists with Login user click productID
                DataTable usersTable = ProductAccess.GetUserLists(Convert.ToString(pd.ProductId), userID);

                if (usersTable.Rows.Count > 0)
                {
                    foreach (DataRow row in usersTable.Rows)
                    {
                        string _userID = row["UserID"].ToString();
                        //Select ProductTable that contains user click history product with userID
                        DataTable table = ProductAccess.GetProductHistoryByUserID(_userID);

                        //Create User Click Stream Data as 0 and 1
                        ProductAccess.CreateUserClickData(table, _userID);

                        //Create  User Profile for current user
                        ProductAccess.CreateUserProfile(_userID, _loginUserID);

                    }
                    // Get Neighborhood Formation And Recommend Product Lists
                    recommendLists.DataSource = ProductAccess.NeighborFormation(usersTable, _loginUserID);
                    recommendLists.DataBind();

                }
                else if (usersTable.Rows.Count == 0) // For product that have no click by users
                {
                    // Get Neighborhood Formation And Recommend Product Lists
                    recommendLists.DataSource = ProductAccess.RecommendationForOthers(pd.brand, pd.year, pd.model, pd.type, pd.Price, pd.colorName, pd.fuel, pd.enginePowerName, pd.handDrive, pd.miles, pd.doorqty, pd.seatqty);
                    recommendLists.DataBind();
                }
                {

                }

                #endregion
            }
            else
            {
                #region Create User Profile, Calculate Similarity and Recommendations
                // Get UserLists with Login user click productID
                DataTable usersTable = ProductAccess.GetUserLists(Convert.ToString(pd.ProductId), userID);

                if (usersTable.Rows.Count > 0)
                {
                    foreach (DataRow row in usersTable.Rows)
                    {
                        string _userID = row["UserID"].ToString();
                        //Select ProductTable that contains user click history product with userID

                        DataTable table = ProductAccess.GetProductHistoryByUserID(_userID);

                        //Create User Click Stream Data as 0 and 1
                        ProductAccess.CreateUserClickData(table, _userID);

                        //Create  User Profile for current user
                        ProductAccess.CreateUserProfile(_userID, _loginUserID);

                    }

                    // Get Neighborhood Formation And Recommend Product Lists
                    recommendLists.DataSource = ProductAccess.NeighborFormation(usersTable, _loginUserID);
                    recommendLists.DataBind();
                }
                #endregion
            }

        }
    }

    private void PopulateControls(ProductDetail pd)
    {
        // Display product details 
        productImage.ImageUrl = "ProductImages/" + pd.image;
        brandLabel.Text = pd.brand;
        yearLabel.Text = pd.year;
        modelLabel.Text = pd.model;
        typeLabel.Text = pd.type;
        priceLabel.Text = string.Format("{0:c}", pd.Price.ToString());
        colorLabel.Text = pd.colorName;
        fuelLabel.Text = pd.fuel;
        engineLabel.Text = pd.enginePowerName.ToString();
        handDriveLabel.Text = pd.handDrive.ToString();
        milageLabel.Text = pd.miles.ToString();
        doorLabel.Text = pd.doorqty.ToString();
        seatLabel.Text = pd.seatqty.ToString();
        descriptionLabel.Text = pd.description.ToString();

    }

    #endregion
}