﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

public partial class AdminHandDrive : System.Web.UI.Page
{
    #region Page_Load
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {// Bind Grid
            BindGrid();

        }

    }
    #endregion

    #region Member Methods

    private void BindGrid()
    {
        grid.DataSource = ProductAccess.GetHandDrive();
        grid.DataBind();
    }

    #endregion

    #region Events
    // Insert HandDrive
    protected void createHandDrive_Click(object sender, EventArgs e)
    {
        DataTable table = ProductAccess.GetHandDrive();

        if (table.Rows.Count >= 2)
        {
            return;

        }
        else
        {
            bool success = ProductAccess.CreateHandDrive(newName.Text);

            statusLabel.Text = success ? "Insert Successful" : "Insert Failed";
            BindGrid();
        }

       
    }

    #endregion
}