﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class AdminBrand : System.Web.UI.Page
{
    #region Page_Load
    protected void Page_Load(object sender, EventArgs e)
    {
        // Load the grid only the first time the page is loaded
        if (!Page.IsPostBack)
        {// Load the Brand to grid
            BindGrid();
        }
    }
    #endregion

    #region Member Methods
    // Populate the GridView with data
    private void BindGrid()
    {
        // get DataTable object containing the brand  attribute
        grid.DataSource = ProductAccess.GetBrand();

        // Bind the data bount controls to the data source
        grid.DataBind();
    }

    #endregion

    #region Events

    // enter edit mode
    protected void grid_RowEditing(object sender, GridViewEditEventArgs e)
    {
        // set the row for which to enable edit mode
        grid.EditIndex = e.NewEditIndex;

        // set stauts message
        statusLabel.Text = "Editing row #" + e.NewEditIndex.ToString();

        // Reload the grid
        BindGrid();
    }

    // Cancel edit mode
    protected void grid_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
    {
        // Cancel edit mode
        grid.EditIndex = -1;
        // set status message
        statusLabel.Text = "Editing Canceled";

        // Reload grid
        BindGrid();

    }

    // update row
    protected void grid_RowUpdating(object sender, GridViewUpdateEventArgs e)
    {
        // Retrive updated data
        string id = grid.DataKeys[e.RowIndex].Value.ToString();
        string name = ((TextBox)grid.Rows[e.RowIndex].Cells[0].Controls[0]).Text;

        // Execute the update command
        bool success = ProductAccess.UpdateBrand(id, name);

        // Cancel edit mode
        grid.EditIndex = -1;

        //Display status message
        statusLabel.Text = success ? "Update Successful" : "Update Failed";
        // Reload the grid
        BindGrid();
    }

    // Delete a record
    protected void grid_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        // Get Id of the record to be deleted
        string id = grid.DataKeys[e.RowIndex].Value.ToString();
        // Execute the delete command
        bool success = ProductAccess.DeleteBrand(id);

        // cancel edit mode
        grid.EditIndex = -1;

        // Display status message
        statusLabel.Text = success ? "Delete Successful" : "Delete Failed";
        // Reload the grid
        BindGrid();
    }

    // Create a new Brand
    protected void createBrand_Click(object sender, EventArgs e)
    {
        // Execute the insert command
        bool success = ProductAccess.CreateBrand(newName.Text);

        // Dsiplay the status message
        statusLabel.Text = success ? "Insert Successful" : "Insert Failed";

        // Reload the grid
        BindGrid();

    }
    #endregion
}