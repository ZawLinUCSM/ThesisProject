﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

public partial class _Default : System.Web.UI.Page
{
    #region Page_Load
    protected void Page_Load(object sender, EventArgs e)
    {
        Populatecontrols();
    }

    #endregion

    #region Events
    protected void searchAdvanced_Click(object sender, EventArgs e)
    {
        LoadSearchProductList();
    }


    #endregion

    #region Member Methods

    private void Populatecontrols()
    {
        #region First Page Load
        // Retrieve Page from the query string 
        string page = Request.QueryString["Page"];

        if (page == null)
        {
            page = "1";

        }
        // How many pages of products
        int howManyPages = 1;
        // pager links format
        string firstPageUrl = "";
        string pageFormat = "";

        // Retrieve list of products on product cleint promo
        list.DataSource = ProductAccess.GetProductsOnClientPromo(page, out howManyPages);
        list.DataBind();

        // have the current page as integer
        int currentPage = Int32.Parse(page);
        firstPageUrl = Link.ToProductList("1");
        pageFormat = Link.ToProductList("{0}");
        // Display pager controls
        topPager.Show(int.Parse(page), howManyPages, firstPageUrl, pageFormat, false);
        bottomPager.Show(int.Parse(page), howManyPages, firstPageUrl, pageFormat, true);
        #endregion

        #region Load Product Search Info
        PopulateBrandAttribute();

        PopulateYearAttribute();

        PopulatePrice();

        PopulateModel();

        PopulateTypeOfCar();
        #endregion

        #region Load Popular Product Lists
        popularLists.DataSource = ProductAccess.GetPopularProductLists();
        popularLabel.Text = "Popular Cars";
        popularLists.DataBind();
        #endregion
    }

    private void LoadSearchProductList()
    {

        // Retrieve Page from the query string 
        string page = Request.QueryString["Page"];

        if (page == null)
        {
            page = "1";

        }
        // How many pages of products
        int howManyPages = 1;
        // pager links format
        string firstPageUrl = "";
        string pageFormat = "";

        // Retrieve list of products on product cleint promo
        list.DataSource = ProductAccess.GetSearchProductList(page, out howManyPages, brandList.SelectedItem.Text, modelList.SelectedItem.Text, typeList.SelectedItem.Text, year1List.SelectedItem.Text, Convert.ToDecimal(price1List.SelectedItem.Text), Convert.ToDecimal(price2List.SelectedItem.Text));
        list.DataBind();

        // have the current page as integer
        int currentPage = Int32.Parse(page);
        firstPageUrl = Link.ToProductList("1");
        pageFormat = Link.ToProductList("{0}");
        // Display pager controls
        topPager.Show(int.Parse(page), howManyPages, firstPageUrl, pageFormat, false);
        bottomPager.Show(int.Parse(page), howManyPages, firstPageUrl, pageFormat, true);
    }

    private void PopulateBrandAttribute()
    {
        DataTable brandTable = ProductAccess.GetBrand();
        string brandid, brandname;

        for (int i = 0; i < brandTable.Rows.Count; i++)
        {
            // obtain brand id and name
            brandid = brandTable.Rows[i]["BrandID"].ToString();
            brandname = brandTable.Rows[i]["BrandName"].ToString();

            // Add to brandList combo box
            brandList.Items.Add(new ListItem(brandname, brandid));

        }
        brandList.SelectedIndex = -1;

    }

    private void PopulateYearAttribute()
    {
        DataTable yearTable = ProductAccess.GetYear();
        string id, year;

        for (int i = 0; i < yearTable.Rows.Count; i++)
        {
            id = yearTable.Rows[i]["YearID"].ToString();
            year = yearTable.Rows[i]["Year"].ToString();

            year1List.Items.Add(new ListItem(year, id));

        }
    }

    private void PopulateModel()
    {
        DataTable modelTable = ProductAccess.GetModel();
        string id, model;

        for (int i = 0; i < modelTable.Rows.Count; i++)
        {
            id = modelTable.Rows[i]["ModelID"].ToString();
            model = modelTable.Rows[i]["ModelName"].ToString();

            modelList.Items.Add(new ListItem(model, id));
        }
    }

    private void PopulateTypeOfCar()
    {
        DataTable carTypeTable = ProductAccess.GetTypeOfCar();
        string id, type;

        for (int i = 0; i < carTypeTable.Rows.Count; i++)
        {
            id = carTypeTable.Rows[i]["TypeID"].ToString();
            type = carTypeTable.Rows[i]["TypeName"].ToString();


            typeList.Items.Add(new ListItem(type, id));
        }
    }

    private void PopulatePrice()
    {
        DataTable priceTable = ProductAccess.GetPrice();
        string id, price;

        for (int i = 0; i < priceTable.Rows.Count; i++)
        {
            id = priceTable.Rows[i]["PriceID"].ToString();
            price = priceTable.Rows[i]["Price"].ToString();

            price1List.Items.Add(new ListItem(price, id));
            price2List.Items.Add(new ListItem(price, id));

        }
    }
    #endregion
}