﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.Common;
using System.Data.SqlClient;


public struct UserInfo
{
    private string userID;

    public string UserID
    {
        get { return userID; }
        set { userID = value; }
    }

    private string userName;

    public string UserName
    {
        get { return userName; }
        set { userName = value; }
    }

    private string email;

    public string Email
    {
        get { return email; }
        set { email = value; }
    }

    private string password;

    public string Password
    {
        get { return password; }
        set { password = value; }
    }
}
/// <summary>
///  Struct for Product details information
/// </summary>
public struct ProductDetail
{
    public int ProductId;
    public string brand;
    public string description;
    public decimal Price;
    public string thumbnail;
    public string image;
    public string model;
    public string type;
    public string handDrive;
    public string enginePowerName;
    public string colorName;
    public string year;
    public string fuel;
    public int doorqty;
    public int seatqty;
    public int miles;
}
/// <summary>
/// Summary description for ProductAccess
/// </summary>
public static class ProductAccess
{
    #region Constructor
    static ProductAccess()
    {
        //
        // TODO: Add constructor logic here
        //
    }
    #endregion

    #region Get Methods

    // Retrieve a list of Brand Attribute
    public static DataTable GetBrand()
    {
        // get a configured DbCommand object
        DbCommand comm = GenericDataAccess.CreateCommand();

        // set the stored procedure
        comm.CommandText = "GetBrandAttribute";

        // execute the stored procedure and return the results
        return GenericDataAccess.ExecuteSelectCommand(comm);
    }

    // Retrieve a list of Year Attribute
    public static DataTable GetYear()
    {
        // get a configured DbCommand object
        DbCommand comm = GenericDataAccess.CreateCommand();

        // set the stored procedure
        comm.CommandText = "GetYearAttribute";

        // execute the stored procedure and return the results
        return GenericDataAccess.ExecuteSelectCommand(comm);
    }

    // Retrieve a list of Model Attribute
    public static DataTable GetModel()
    {
        // get a configured DbCommand object
        DbCommand comm = GenericDataAccess.CreateCommand();

        // set the stored procedure
        comm.CommandText = "GetModelAttribute";

        // execute the stored procedure and return the results
        return GenericDataAccess.ExecuteSelectCommand(comm);
    }

    // Retrieve a list of Type of Car Attribute
    public static DataTable GetTypeOfCar()
    {
        // get a configured DbCommand object
        DbCommand comm = GenericDataAccess.CreateCommand();

        // set the stored procedure
        comm.CommandText = "GetTypeAttribute";

        // execute the stored procedure and return the results
        return GenericDataAccess.ExecuteSelectCommand(comm);
    }

    // Retrieve a list of Price Attribute
    public static DataTable GetPrice()
    {
        // get a configured DbCommand object
        DbCommand comm = GenericDataAccess.CreateCommand();

        // set the stored procedure
        comm.CommandText = "GetPriceAttribute";

        // execute the stored procedure and return the results
        return GenericDataAccess.ExecuteSelectCommand(comm);
    }

    // Retrieve a list of Color Attribute
    public static DataTable GetColor()
    {
        // get a configured DbCommand object
        DbCommand comm = GenericDataAccess.CreateCommand();

        // set the stored procedure
        comm.CommandText = "GetColorAttribute";

        // execute the stored procedure and return the results
        return GenericDataAccess.ExecuteSelectCommand(comm);
    }

    // Retrieve a list of Fuel Attribte
    public static DataTable GetFuel()
    {
        // get a configured DbCommand object
        DbCommand comm = GenericDataAccess.CreateCommand();

        // set the stored procedure
        comm.CommandText = "GetFuelAttribute";

        // execute the stored procedure and return the results
        return GenericDataAccess.ExecuteSelectCommand(comm);
    }

    // Retreive a list of Engine Power Attribute
    public static DataTable GetEnginePower()
    {
        // get a configured DbCommand object
        DbCommand comm = GenericDataAccess.CreateCommand();

        // set the stored procedure
        comm.CommandText = "GetEnginePowerAttribute";

        // execute the stored procedure and return the results
        return GenericDataAccess.ExecuteSelectCommand(comm);
    }

    // Retrieve a list of HandDrive Attribute
    public static DataTable GetHandDrive()
    {
        // get a configured DbCommand object
        DbCommand comm = GenericDataAccess.CreateCommand();

        // set the stored procedure
        comm.CommandText = "GetHandDriveAttribute";

        // execute the stored procedure and return the results
        return GenericDataAccess.ExecuteSelectCommand(comm);
    }

    // Retrieve a list of Milage Attribute
    public static DataTable GetMilage()
    {
        // get a configured DbCommand object
        DbCommand comm = GenericDataAccess.CreateCommand();

        // set the stored procedure
        comm.CommandText = "GetMilageAttribute";

        // execute the stored procedure and return the results
        return GenericDataAccess.ExecuteSelectCommand(comm);
    }

    // Retrieve a list of Door Attribute
    public static DataTable GetDoors()
    {
        // get a configured DbCommand object
        DbCommand comm = GenericDataAccess.CreateCommand();

        // set the stored procedure
        comm.CommandText = "GetDoorAttribute";

        // execute the stored procedure and return the results
        return GenericDataAccess.ExecuteSelectCommand(comm);
    }

    // Retrieve a list of Seat Attribute
    public static DataTable GetSeat()
    {
        // get a configured DbCommand object
        DbCommand comm = GenericDataAccess.CreateCommand();

        // set the stored procedure
        comm.CommandText = "GetSeatAttribute";

        // execute the stored procedure and return the results
        return GenericDataAccess.ExecuteSelectCommand(comm);
    }

    // Retrieve name of brand from brandid
    public static DataTable GetBrand(string id)
    {
        DbCommand comm = GenericDataAccess.CreateCommand();
        comm.CommandText = "GetBrandName";
        DbParameter param = comm.CreateParameter();
        param.ParameterName = "@BrandID";
        param.Value = id;
        param.DbType = DbType.Int32;
        comm.Parameters.Add(param);

        return GenericDataAccess.ExecuteSelectCommand(comm);
    }


    // Retrieve name of model from modelId
    public static DataTable GetModel(string id)
    {
        DbCommand comm = GenericDataAccess.CreateCommand();
        comm.CommandText = "GetModelName";
        DbParameter param = comm.CreateParameter();
        param.ParameterName = "@ModelID";
        param.Value = id;
        param.DbType = DbType.Int32;
        comm.Parameters.Add(param);

        return GenericDataAccess.ExecuteSelectCommand(comm);
    }

    // Retrieve price from priceID
    public static DataTable GetPrice(string id)
    {
        DbCommand comm = GenericDataAccess.CreateCommand();
        comm.CommandText = "GetPriceName";
        DbParameter param = comm.CreateParameter();
        param.ParameterName = "@PriceID";
        param.Value = id;
        param.DbType = DbType.Int32;
        comm.Parameters.Add(param);

        return GenericDataAccess.ExecuteSelectCommand(comm);
    }

    public static DataTable GetProductLists()
    {
        DbCommand comm = GenericDataAccess.CreateCommand();
        comm.CommandText = "GetProductLists";
        return GenericDataAccess.ExecuteSelectCommand(comm);

    }

    #endregion

    #region GetAttributeWithProduct

    public static DataTable GetBrandWithProduct(string productID)
    {
        DbCommand comm = GenericDataAccess.CreateCommand();
        comm.CommandText = "GetBrandWithProduct";
        DbParameter param = comm.CreateParameter();
        param.ParameterName = "@ProductID";
        param.Value = productID;
        param.DbType = DbType.Int32;
        comm.Parameters.Add(param);

        return GenericDataAccess.ExecuteSelectCommand(comm);

    }

    public static DataTable GetYearWithProduct(string productID)
    {
        DbCommand comm = GenericDataAccess.CreateCommand();
        comm.CommandText = "GetYearWithProduct";
        DbParameter param = comm.CreateParameter();
        param.ParameterName = "@ProductID";
        param.Value = productID;
        param.DbType = DbType.Int32;
        comm.Parameters.Add(param);

        return GenericDataAccess.ExecuteSelectCommand(comm);
    }

    public static DataTable GetModelWithProduct(string productID)
    {
        DbCommand comm = GenericDataAccess.CreateCommand();
        comm.CommandText = "GetModelWithProduct";
        DbParameter param = comm.CreateParameter();
        param.ParameterName = "@ProductID";
        param.Value = productID;
        param.DbType = DbType.Int32;
        comm.Parameters.Add(param);

        return GenericDataAccess.ExecuteSelectCommand(comm);
    }

    public static DataTable GetTypeWithProduct(string productID)
    {
        DbCommand comm = GenericDataAccess.CreateCommand();
        comm.CommandText = "GetTypeWithProduct";
        DbParameter param = comm.CreateParameter();
        param.ParameterName = "@ProductID";
        param.Value = productID;
        param.DbType = DbType.Int32;
        comm.Parameters.Add(param);

        return GenericDataAccess.ExecuteSelectCommand(comm);
    }

    public static DataTable GetPriceWithProduct(string productID)
    {
        DbCommand comm = GenericDataAccess.CreateCommand();
        comm.CommandText = "GetPriceWithProduct";
        DbParameter param = comm.CreateParameter();
        param.ParameterName = "@ProductID";
        param.Value = productID;
        param.DbType = DbType.Int32;
        comm.Parameters.Add(param);

        return GenericDataAccess.ExecuteSelectCommand(comm);
    }

    public static DataTable GetColorWithProduct(string productID)
    {
        DbCommand comm = GenericDataAccess.CreateCommand();
        comm.CommandText = "GetColorWithProduct";
        DbParameter param = comm.CreateParameter();
        param.ParameterName = "@ProductID";
        param.Value = productID;
        param.DbType = DbType.Int32;
        comm.Parameters.Add(param);

        return GenericDataAccess.ExecuteSelectCommand(comm);
    }

    public static DataTable GetFuelWithProduct(string productID)
    {
        DbCommand comm = GenericDataAccess.CreateCommand();
        comm.CommandText = "GetFuelWithProduct";
        DbParameter param = comm.CreateParameter();
        param.ParameterName = "@ProductID";
        param.Value = productID;
        param.DbType = DbType.Int32;
        comm.Parameters.Add(param);

        return GenericDataAccess.ExecuteSelectCommand(comm);
    }

    public static DataTable GetEnginePowerWithProduct(string productID)
    {
        DbCommand comm = GenericDataAccess.CreateCommand();
        comm.CommandText = "GetEnginePowerWithProduct";
        DbParameter param = comm.CreateParameter();
        param.ParameterName = "@ProductID";
        param.Value = productID;
        param.DbType = DbType.Int32;
        comm.Parameters.Add(param);

        return GenericDataAccess.ExecuteSelectCommand(comm);
    }

    public static DataTable GetHandDriveWithProduct(string productID)
    {
        DbCommand comm = GenericDataAccess.CreateCommand();
        comm.CommandText = "GetHandDriveWithProduct";
        DbParameter param = comm.CreateParameter();
        param.ParameterName = "@ProductID";
        param.Value = productID;
        param.DbType = DbType.Int32;
        comm.Parameters.Add(param);

        return GenericDataAccess.ExecuteSelectCommand(comm);
    }

    public static DataTable GetMilageWithProduct(string productID)
    {
        DbCommand comm = GenericDataAccess.CreateCommand();
        comm.CommandText = "GetMilageWithProduct";
        DbParameter param = comm.CreateParameter();
        param.ParameterName = "@ProductID";
        param.Value = productID;
        param.DbType = DbType.Int32;
        comm.Parameters.Add(param);

        return GenericDataAccess.ExecuteSelectCommand(comm);
    }

    public static DataTable GetDoorWithProduct(string productID)
    {
        DbCommand comm = GenericDataAccess.CreateCommand();
        comm.CommandText = "GetDoorWithProduct";
        DbParameter param = comm.CreateParameter();
        param.ParameterName = "@ProductID";
        param.Value = productID;
        param.DbType = DbType.Int32;
        comm.Parameters.Add(param);

        return GenericDataAccess.ExecuteSelectCommand(comm);
    }

    public static DataTable GetSeatWithProduct(string productID)
    {
        DbCommand comm = GenericDataAccess.CreateCommand();
        comm.CommandText = "GetSeatWithProduct";
        DbParameter param = comm.CreateParameter();
        param.ParameterName = "@ProductID";
        param.Value = productID;
        param.DbType = DbType.Int32;
        comm.Parameters.Add(param);

        return GenericDataAccess.ExecuteSelectCommand(comm);
    }

    public static DataTable GetProductDescriptionAndOthers(string productID)
    {
        DbCommand comm = GenericDataAccess.CreateCommand();
        comm.CommandText = "GetProductDescriptionAndOthers";
        DbParameter param = comm.CreateParameter();
        param.ParameterName = "@ProductID";
        param.Value = productID;
        param.DbType = DbType.Int32;
        comm.Parameters.Add(param);

        return GenericDataAccess.ExecuteSelectCommand(comm);
    }

    #endregion

    #region GetProductsOnClientPromo

    public static DataTable GetProductsOnClientPromo(string pageNumber, out int howManyPages)
    {
        // get a configured DbCommand object
        DbCommand comm = GenericDataAccess.CreateCommand();

        // set the stored procedure name
        comm.CommandText = "GetProductsOnClientPromo";
        // Create a parameter
        DbParameter param = comm.CreateParameter();
        param.ParameterName = "@DescriptionLength";
        param.Value = OCRConfiguration.ProductDescriptionLength;
        param.DbType = DbType.Int32;
        comm.Parameters.Add(param);

        // Create a parameter
        param = comm.CreateParameter();
        param.ParameterName = "@PageNumber";
        param.Value = pageNumber;
        param.DbType = DbType.Int32;
        comm.Parameters.Add(param);

        // Create a parameter
        param = comm.CreateParameter();
        param.ParameterName = "@ProductsPerPage";
        param.Value = OCRConfiguration.ProductsPerPage;
        param.DbType = DbType.Int32;
        comm.Parameters.Add(param);

        // Create a parameter
        param = comm.CreateParameter();
        param.ParameterName = "@HowManyProducts";
        param.Direction = ParameterDirection.Output;
        param.DbType = DbType.Int32;
        comm.Parameters.Add(param);

        //execute the stored pro and save the results in a DataTable
        DataTable table = GenericDataAccess.ExecuteSelectCommand(comm);

        // Calculate how many pages of products and set out parameter
        int howManyProducts = Int32.Parse(comm.Parameters["@HowManyProducts"].Value.ToString());

        howManyPages = (int)Math.Ceiling((double)howManyProducts / (double)OCRConfiguration.ProductsPerPage);

        // return the page of products
        return table;
    }

    #endregion

    #region GetProductDetails

    public static ProductDetail GetProductDetailsWithProduct(string productId)
    {
        DbCommand comm = GenericDataAccess.CreateCommand();
        comm.CommandText = "GetProducts";
        DbParameter param = comm.CreateParameter();
        param.ParameterName = "@ProductID";
        param.Value = productId;
        param.DbType = DbType.Int32;

        comm.Parameters.Add(param);

        // Execute the stored procedure
        DataTable table = GenericDataAccess.ExecuteSelectCommand(comm);

        // Wrap retrieved data into ProductDetails object
        ProductDetail details = new ProductDetail();

        if (table.Rows.Count > 0)
        {
            // Get the first table row
            DataRow row = table.Rows[0];

            // get product details
            details.ProductId = int.Parse(productId);
            details.brand = row["BrandName"].ToString();
            details.year = row["Year"].ToString();
            details.model = row["ModelName"].ToString();
            details.type = row["TypeName"].ToString();
            details.Price = Decimal.Parse(row["Price"].ToString());
            details.colorName = row["ColorName"].ToString();
            details.fuel = row["FuelName"].ToString();
            details.enginePowerName = row["EngineName"].ToString();
            details.handDrive = row["HandDriveName"].ToString();
            details.miles = Int32.Parse(row["Milage"].ToString());
            details.doorqty = Int32.Parse(row["DoorQty"].ToString());
            details.seatqty = Int32.Parse(row["SeatQty"].ToString());
            details.description = row["Description"].ToString();
            details.thumbnail = row["Thumbnail"].ToString();
            details.image = row["Image"].ToString();


        }

        // Return Product Details
        return details;

    }

    public static void SaveClickProduct(int productId, string userID, string brand, string year, string model, string type, decimal price, string colorName, string fuel, string engineName, string handDrive, int miles, int door, int seat)
    {
        // Get a configured DbCommnad object
        DbCommand comm = GenericDataAccess.CreateCommand();
        // Set the stored procedure name
        comm.CommandText = "CreateProductHistory";
        //Create a new parameter
        DbParameter param = comm.CreateParameter();
        param.ParameterName = "@ProductID";
        param.Value = productId;
        param.DbType = DbType.Int32;
        comm.Parameters.Add(param);

        param = comm.CreateParameter();
        param.ParameterName = "@UserID";
        param.Value = userID;
        param.DbType = DbType.String;
        comm.Parameters.Add(param);

        param = comm.CreateParameter();
        param.ParameterName = "@Brand";
        param.Value = brand;
        param.DbType = DbType.String;
        comm.Parameters.Add(param);

        param = comm.CreateParameter();
        param.ParameterName = "@Year";
        param.Value = year;
        param.DbType = DbType.String;
        comm.Parameters.Add(param);

        param = comm.CreateParameter();
        param.ParameterName = "@Model";
        param.Value = model;
        param.DbType = DbType.String;
        comm.Parameters.Add(param);

        param = comm.CreateParameter();
        param.ParameterName = "@Type";
        param.Value = type;
        param.DbType = DbType.String;
        comm.Parameters.Add(param);

        param = comm.CreateParameter();
        param.ParameterName = "@Color";
        param.Value = colorName;
        param.DbType = DbType.String;
        comm.Parameters.Add(param);

        param = comm.CreateParameter();
        param.ParameterName = "@Fuel";
        param.Value = fuel;
        param.DbType = DbType.String;
        comm.Parameters.Add(param);

        param = comm.CreateParameter();
        param.ParameterName = "@EngineName";
        param.Value = engineName;
        param.DbType = DbType.String;
        comm.Parameters.Add(param);

        param = comm.CreateParameter();
        param.ParameterName = "@HandDrive";
        param.Value = handDrive;
        param.DbType = DbType.String;
        comm.Parameters.Add(param);

        param = comm.CreateParameter();
        param.ParameterName = "@Mile";
        param.Value = miles;
        param.DbType = DbType.Int32;
        comm.Parameters.Add(param);

        param = comm.CreateParameter();
        param.ParameterName = "@Door";
        param.Value = door;
        param.DbType = DbType.Int32;
        comm.Parameters.Add(param);

        param = comm.CreateParameter();
        param.ParameterName = "@Seat";
        param.Value = seat;
        param.DbType = DbType.Int32;
        comm.Parameters.Add(param);

        param = comm.CreateParameter();
        param.ParameterName = "@Price";
        param.Value = price;
        param.DbType = DbType.Decimal;
        comm.Parameters.Add(param);

        try
        {// execute the stored procedure
            int result = GenericDataAccess.ExecuteNonQuery(comm);
        }
        catch
        {


        }

    }

    #endregion

    #region GetProductHistory
    public static DataTable GetProductHistoryByUserID(string userId)
    {
        DbCommand comm = GenericDataAccess.CreateCommand();
        comm.CommandText = "GetProductHistoryByUserID";

        DbParameter param = comm.CreateParameter();
        param.ParameterName = "@UserID";
        param.Value = userId;
        param.DbType = DbType.String;
        comm.Parameters.Add(param);

        //param = comm.CreateParameter();
        //param.ParameterName = "@ProductID";
        //param.Value = productId;
        //param.DbType = DbType.Int32;
        //comm.Parameters.Add(param);

        return GenericDataAccess.ExecuteSelectCommand(comm);
    }

    #endregion

    #region Create/Update/Delete Methods

    #region Create Methods
    // insert all attributes 
    public static bool CreateBrand(string brandname)
    {
        // Get a configured DbCommnad object
        DbCommand comm = GenericDataAccess.CreateCommand();
        // Set the stored procedure name
        comm.CommandText = "CreateBrandAttribute";
        //Create a new parameter
        DbParameter param = comm.CreateParameter();
        param.ParameterName = "@BrandName";
        param.Value = brandname;
        param.DbType = DbType.String;
        comm.Parameters.Add(param);

        //result will represent the number of changed rows
        int result = -1;
        try
        {// execute the stored procedure
            result = GenericDataAccess.ExecuteNonQuery(comm);
        }
        catch
        {


        }

        // result will be 1 in case of success
        return (result != -1);
    }

    public static bool CreateYear(string insertdate)
    {
        // Get a configured DbCommnad object
        DbCommand comm = GenericDataAccess.CreateCommand();
        // Set the stored procedure name
        comm.CommandText = "CreateYearAttribute";
        //Create a new parameter
        DbParameter param = comm.CreateParameter();
        param.ParameterName = "@Year";
        // DateTime dt = Convert.ToDateTime(insertdate);

        param.Value = insertdate;
        param.DbType = DbType.String;
        comm.Parameters.Add(param);

        //result will represent the number of changed rows
        int result = -1;
        try
        {// execute the stored procedure
            result = GenericDataAccess.ExecuteNonQuery(comm);
        }
        catch
        {


        }

        // result will be 1 in case of success
        return (result != -1);
    }

    public static bool CreateModel(string modelname)
    {
        // Get a configured DbCommnad object
        DbCommand comm = GenericDataAccess.CreateCommand();
        // Set the stored procedure name
        comm.CommandText = "CreateModelAttribute";
        //Create a new parameter
        DbParameter param = comm.CreateParameter();
        param.ParameterName = "@ModelName";
        param.Value = modelname;
        param.DbType = DbType.String;
        comm.Parameters.Add(param);

        //result will represent the number of changed rows
        int result = -1;
        try
        {// execute the stored procedure
            result = GenericDataAccess.ExecuteNonQuery(comm);
        }
        catch
        {


        }

        // result will be 1 in case of success
        return (result != -1);
    }

    public static bool CreateTypeOfCar(string typeName)
    {
        // Get a configured DbCommnad object
        DbCommand comm = GenericDataAccess.CreateCommand();
        // Set the stored procedure name
        comm.CommandText = "CreateTypeAttribute";
        //Create a new parameter
        DbParameter param = comm.CreateParameter();
        param.ParameterName = "@TypeName";
        param.Value = typeName;
        param.DbType = DbType.String;
        comm.Parameters.Add(param);

        //result will represent the number of changed rows
        int result = -1;
        try
        {// execute the stored procedure
            result = GenericDataAccess.ExecuteNonQuery(comm);
        }
        catch
        {


        }

        // result will be 1 in case of success
        return (result != -1);
    }

    public static bool CreatePrice(decimal price)
    {
        // Get a configured DbCommnad object
        DbCommand comm = GenericDataAccess.CreateCommand();
        // Set the stored procedure name
        comm.CommandText = "CreatePriceAttribute";
        //Create a new parameter
        DbParameter param = comm.CreateParameter();
        param.ParameterName = "@Price";
        param.Value = price;
        param.DbType = DbType.Decimal;
        comm.Parameters.Add(param);

        //result will represent the number of changed rows
        int result = -1;
        try
        {// execute the stored procedure
            result = GenericDataAccess.ExecuteNonQuery(comm);
        }
        catch
        {


        }

        // result will be 1 in case of success
        return (result != -1);
    }

    public static bool CreateFuel(string fuelname)
    {
        // Get a configured DbCommnad object
        DbCommand comm = GenericDataAccess.CreateCommand();
        // Set the stored procedure name
        comm.CommandText = "CreateFuelAttribute";
        //Create a new parameter
        DbParameter param = comm.CreateParameter();
        param.ParameterName = "@FuelName";
        param.Value = fuelname;
        param.DbType = DbType.String;
        comm.Parameters.Add(param);

        //result will represent the number of changed rows
        int result = -1;
        try
        {// execute the stored procedure
            result = GenericDataAccess.ExecuteNonQuery(comm);
        }
        catch
        {


        }

        // result will be 1 in case of success
        return (result != -1);
    }

    public static bool CreateEnginePower(string engine)
    {
        // Get a configured DbCommnad object
        DbCommand comm = GenericDataAccess.CreateCommand();
        // Set the stored procedure name
        comm.CommandText = "CreateEnginePowerAttribute";
        //Create a new parameter
        DbParameter param = comm.CreateParameter();
        param.ParameterName = "@EngineName";
        param.Value = engine;
        param.DbType = DbType.String;
        comm.Parameters.Add(param);

        //result will represent the number of changed rows
        int result = -1;
        try
        {// execute the stored procedure
            result = GenericDataAccess.ExecuteNonQuery(comm);
        }
        catch
        {


        }

        // result will be 1 in case of success
        return (result != -1);
    }

    public static bool CreateHandDrive(string handDrive)
    {
        // Get a configured DbCommnad object
        DbCommand comm = GenericDataAccess.CreateCommand();
        // Set the stored procedure name
        comm.CommandText = "CreateHandDriveAttribute";
        //Create a new parameter
        DbParameter param = comm.CreateParameter();
        param.ParameterName = "@HandDriveName";
        param.Value = handDrive;
        param.DbType = DbType.String;
        comm.Parameters.Add(param);

        //result will represent the number of changed rows
        int result = -1;
        try
        {// execute the stored procedure
            result = GenericDataAccess.ExecuteNonQuery(comm);
        }
        catch
        {


        }

        // result will be 1 in case of success
        return (result != -1);
    }

    public static bool CreateMilage(int miles)
    {
        // Get a configured DbCommnad object
        DbCommand comm = GenericDataAccess.CreateCommand();
        // Set the stored procedure name
        comm.CommandText = "CreateMilageAttribute";
        //Create a new parameter
        DbParameter param = comm.CreateParameter();
        param.ParameterName = "@Milage";
        param.Value = miles;
        param.DbType = DbType.Int32;
        comm.Parameters.Add(param);

        //result will represent the number of changed rows
        int result = -1;
        try
        {// execute the stored procedure
            result = GenericDataAccess.ExecuteNonQuery(comm);
        }
        catch
        {


        }

        // result will be 1 in case of success
        return (result != -1);
    }

    public static bool CreateDoor(int door)
    {
        // Get a configured DbCommnad object
        DbCommand comm = GenericDataAccess.CreateCommand();
        // Set the stored procedure name
        comm.CommandText = "CreateDoorAttribute";
        //Create a new parameter
        DbParameter param = comm.CreateParameter();
        param.ParameterName = "@DoorQty";
        param.Value = door;
        param.DbType = DbType.Int32;
        comm.Parameters.Add(param);

        //result will represent the number of changed rows
        int result = -1;
        try
        {// execute the stored procedure
            result = GenericDataAccess.ExecuteNonQuery(comm);
        }
        catch
        {


        }

        // result will be 1 in case of success
        return (result != -1);
    }

    public static bool CreateSeat(int seat)
    {
        // Get a configured DbCommnad object
        DbCommand comm = GenericDataAccess.CreateCommand();
        // Set the stored procedure name
        comm.CommandText = "CreateSeatAttribute";
        //Create a new parameter
        DbParameter param = comm.CreateParameter();
        param.ParameterName = "@SeatQty";
        param.Value = seat;
        param.DbType = DbType.Int32;
        comm.Parameters.Add(param);

        //result will represent the number of changed rows
        int result = -1;
        try
        {// execute the stored procedure
            result = GenericDataAccess.ExecuteNonQuery(comm);
        }
        catch
        {


        }

        // result will be 1 in case of success
        return (result != -1);
    }

    public static bool CreateColor(string colorname)
    {
        // Get a configured DbCommnad object
        DbCommand comm = GenericDataAccess.CreateCommand();
        // Set the stored procedure name
        comm.CommandText = "CreateColorAttribute";
        //Create a new parameter
        DbParameter param = comm.CreateParameter();
        param.ParameterName = "@ColorName";
        param.Value = colorname;
        param.DbType = DbType.String;
        comm.Parameters.Add(param);

        //result will represent the number of changed rows
        int result = -1;
        try
        {// execute the stored procedure
            result = GenericDataAccess.ExecuteNonQuery(comm);
        }
        catch
        {


        }

        // result will be 1 in case of success
        return (result != -1);
    }

    public static bool CreateProduct(string brandID, string yearID, string modelID, string typeID, string priceID, string colorID, string fuelID, string engineID, string handID, string milageID, string doorID, string seatID, string desc, string thumbnail, string image, decimal price, string name)
    {
        // Get a configured DbCommnad object
        DbCommand comm = GenericDataAccess.CreateCommand();
        // Set the stored procedure name
        comm.CommandText = "CreateProduct";
        //Create a new parameter
        DbParameter param = comm.CreateParameter();
        param.ParameterName = "@BrandID";
        param.Value = brandID;
        param.DbType = DbType.Int32;
        comm.Parameters.Add(param);

        param = comm.CreateParameter();
        param.ParameterName = "@YearID";
        param.Value = yearID;
        param.DbType = DbType.Int32;
        comm.Parameters.Add(param);

        param = comm.CreateParameter();
        param.ParameterName = "ModelID";
        param.Value = modelID;
        param.DbType = DbType.Int32;
        comm.Parameters.Add(param);

        param = comm.CreateParameter();
        param.ParameterName = "@TypeID";
        param.Value = typeID;
        param.DbType = DbType.Int32;
        comm.Parameters.Add(param);

        param = comm.CreateParameter();
        param.ParameterName = "@PriceID";
        param.Value = priceID;
        param.DbType = DbType.Int32;
        comm.Parameters.Add(param);

        param = comm.CreateParameter();
        param.ParameterName = "@ColorID";
        param.Value = colorID;
        param.DbType = DbType.Int32;
        comm.Parameters.Add(param);

        param = comm.CreateParameter();
        param.ParameterName = "@FuelID";
        param.Value = fuelID;
        param.DbType = DbType.Int32;
        comm.Parameters.Add(param);

        param = comm.CreateParameter();
        param.ParameterName = "@EnginePowerID";
        param.Value = engineID;
        param.DbType = DbType.Int32;
        comm.Parameters.Add(param);

        param = comm.CreateParameter();
        param.ParameterName = "@HandDriveID";
        param.Value = handID;
        param.DbType = DbType.Int32;
        comm.Parameters.Add(param);

        param = comm.CreateParameter();
        param.ParameterName = "@MilageID";
        param.Value = milageID;
        param.DbType = DbType.Int32;
        comm.Parameters.Add(param);

        param = comm.CreateParameter();
        param.ParameterName = "@DoorID";
        param.Value = doorID;
        param.DbType = DbType.Int32;
        comm.Parameters.Add(param);

        param = comm.CreateParameter();
        param.ParameterName = "@SeatID";
        param.Value = seatID;
        param.DbType = DbType.Int32;
        comm.Parameters.Add(param);

        param = comm.CreateParameter();
        param.ParameterName = "@Description";
        param.Value = desc;
        param.DbType = DbType.String;
        comm.Parameters.Add(param);

        param = comm.CreateParameter();
        param.ParameterName = "@Thumbnail";
        param.Value = thumbnail;
        param.DbType = DbType.String;
        comm.Parameters.Add(param);

        param = comm.CreateParameter();
        param.ParameterName = "@Image";
        param.Value = image;
        param.DbType = DbType.String;
        comm.Parameters.Add(param);

        param = comm.CreateParameter();
        param.ParameterName = "@Name";
        param.Value = name;
        param.DbType = DbType.String;
        comm.Parameters.Add(param);

        param = comm.CreateParameter();
        param.ParameterName = "@Price";
        param.Value = price;
        param.DbType = DbType.Decimal;
        comm.Parameters.Add(param);

        //result will represent the number of changed rows
        int result = -1;
        try
        {// execute the stored procedure
            result = GenericDataAccess.ExecuteNonQuery(comm);
        }
        catch
        {


        }

        // result will be 1 in case of success
        return (result != -1);
    }
    #endregion

    #region Update Methods
    // update brand attribute
    public static bool UpdateBrand(string id, string brandname)
    {
        // get a configured Dbcommand object
        DbCommand comm = GenericDataAccess.CreateCommand();

        // Set the stored procedure
        comm.CommandText = "UpdateBrandAttribute";

        //Create a paramenter
        DbParameter param = comm.CreateParameter();
        param.ParameterName = "@BrandID";
        param.Value = id;
        param.DbType = DbType.Int32;
        comm.Parameters.Add(param);

        //Create a paramenter
        param = comm.CreateParameter();
        param.ParameterName = "@BrandName";
        param.Value = brandname;
        param.DbType = DbType.String;
        comm.Parameters.Add(param);

        // result will represent the number of changed rows
        int result = -1;
        try
        {
            result = GenericDataAccess.ExecuteNonQuery(comm);

        }
        catch
        {
            // any errors are logged in GenericDataAccess,  ignore them here 

        }

        // result will be 1 in case of success
        return (result != -1);
    }

    // update Color
    public static bool UpdateColor(string id, string color)
    {
        // get a configured Dbcommand object
        DbCommand comm = GenericDataAccess.CreateCommand();

        // Set the stored procedure
        comm.CommandText = "UpdateColorAttribute";

        //Create a paramenter
        DbParameter param = comm.CreateParameter();
        param.ParameterName = "@ColorID";
        param.Value = id;
        param.DbType = DbType.Int32;
        comm.Parameters.Add(param);

        //Create a paramenter
        param = comm.CreateParameter();
        param.ParameterName = "@ColorName";
        param.Value = color;
        param.DbType = DbType.String;
        comm.Parameters.Add(param);

        // result will represent the number of changed rows
        int result = -1;
        try
        {
            result = GenericDataAccess.ExecuteNonQuery(comm);

        }
        catch
        {
            // any errors are logged in GenericDataAccess,  ignore them here 

        }

        // result will be 1 in case of success
        return (result != -1);
    }

    // update Model
    public static bool UpdateModel(string id, string model)
    {
        // get a configured Dbcommand object
        DbCommand comm = GenericDataAccess.CreateCommand();

        // Set the stored procedure
        comm.CommandText = "UpdateModelAttribute";

        //Create a paramenter
        DbParameter param = comm.CreateParameter();
        param.ParameterName = "@ModelID";
        param.Value = id;
        param.DbType = DbType.Int32;
        comm.Parameters.Add(param);

        //Create a paramenter
        param = comm.CreateParameter();
        param.ParameterName = "@ModelName";
        param.Value = model;
        param.DbType = DbType.String;
        comm.Parameters.Add(param);

        // result will represent the number of changed rows
        int result = -1;
        try
        {
            result = GenericDataAccess.ExecuteNonQuery(comm);

        }
        catch
        {
            // any errors are logged in GenericDataAccess,  ignore them here 

        }

        // result will be 1 in case of success
        return (result != -1);
    }

    // update Type
    public static bool UpdateType(string id, string type)
    {
        // get a configured Dbcommand object
        DbCommand comm = GenericDataAccess.CreateCommand();

        // Set the stored procedure
        comm.CommandText = "UpdateTypeAttribute";

        //Create a paramenter
        DbParameter param = comm.CreateParameter();
        param.ParameterName = "@TypeID";
        param.Value = id;
        param.DbType = DbType.Int32;
        comm.Parameters.Add(param);

        //Create a paramenter
        param = comm.CreateParameter();
        param.ParameterName = "@TypeName";
        param.Value = type;
        param.DbType = DbType.String;
        comm.Parameters.Add(param);

        // result will represent the number of changed rows
        int result = -1;
        try
        {
            result = GenericDataAccess.ExecuteNonQuery(comm);

        }
        catch
        {
            // any errors are logged in GenericDataAccess,  ignore them here 

        }

        // result will be 1 in case of success
        return (result != -1);
    }

    // update Price
    public static bool UpdatePrice(string id, string price)
    {
        // get a configured Dbcommand object
        DbCommand comm = GenericDataAccess.CreateCommand();

        // Set the stored procedure
        comm.CommandText = "UpdatePriceAttribute";

        //Create a paramenter
        DbParameter param = comm.CreateParameter();
        param.ParameterName = "@PriceID";
        param.Value = id;
        param.DbType = DbType.Int32;
        comm.Parameters.Add(param);

        //Create a paramenter
        param = comm.CreateParameter();
        param.ParameterName = "@Price";
        param.Value = price;
        param.DbType = DbType.Decimal;
        comm.Parameters.Add(param);

        // result will represent the number of changed rows
        int result = -1;
        try
        {
            result = GenericDataAccess.ExecuteNonQuery(comm);

        }
        catch
        {
            // any errors are logged in GenericDataAccess,  ignore them here 

        }

        // result will be 1 in case of success
        return (result != -1);
    }

    public static bool UpdateUser(string id, string name, string email)
    {
        // get a configured Dbcommand object
        DbCommand comm = GenericDataAccess.CreateCommand();
        comm.CommandText = "UpdateUser";


        DbParameter param = comm.CreateParameter();
        param.ParameterName = "@UserID";
        param.Value = id;
        param.DbType = DbType.String;
        comm.Parameters.Add(param);

        // Create a Parameter
        param = comm.CreateParameter();
        param.ParameterName = "@Name";
        param.Value = name;
        param.DbType = DbType.String;
        comm.Parameters.Add(param);

        // Create a parameter
        param = comm.CreateParameter();
        param.ParameterName = "@Email";
        param.Value = email;
        param.DbType = DbType.String;
        comm.Parameters.Add(param);



        // result will represent the number of changed rows
        int result = -1;
        try
        {
            result = GenericDataAccess.ExecuteNonQuery(comm);

        }
        catch
        {
            // any errors are logged in GenericDataAccess,  ignore them here 

        }

        // result will be 1 in case of success
        return (result != -1);


    }

    #endregion

    #region Delete Methods

    // delete brand attribute
    public static bool DeleteBrand(string id)
    {
        // get a configured Dbcommand object
        DbCommand comm = GenericDataAccess.CreateCommand();

        // Set the stored procedure
        comm.CommandText = "DeleteBrandAttribute";

        //Create a paramenter
        DbParameter param = comm.CreateParameter();
        param.ParameterName = "@BrandID";
        param.Value = id;
        param.DbType = DbType.Int32;
        comm.Parameters.Add(param);

        int result = -1;
        try
        {
            // execute command
            result = GenericDataAccess.ExecuteNonQuery(comm);
        }
        catch
        {
            // any errors are logged in GenericDataAccess, ignoer them here

        }
        // result will be 1 in case of success

        return (result != -1);

    }

    // delete Color 
    public static bool DeleteColor(string id)
    {
        // get a configured Dbcommand object
        DbCommand comm = GenericDataAccess.CreateCommand();

        // Set the stored procedure
        comm.CommandText = "DeleteColor";

        //Create a paramenter
        DbParameter param = comm.CreateParameter();
        param.ParameterName = "@ColorID";
        param.Value = id;
        param.DbType = DbType.Int32;
        comm.Parameters.Add(param);

        int result = -1;
        try
        {
            // execute command
            result = GenericDataAccess.ExecuteNonQuery(comm);
        }
        catch
        {
            // any errors are logged in GenericDataAccess, ignoer them here

        }
        // result will be 1 in case of success

        return (result != -1);
    }

    // delete Model
    public static bool DeleteModel(string id)
    {
        // get a configured Dbcommand object
        DbCommand comm = GenericDataAccess.CreateCommand();

        // Set the stored procedure
        comm.CommandText = "DeleteModel";

        //Create a paramenter
        DbParameter param = comm.CreateParameter();
        param.ParameterName = "@ModelID";
        param.Value = id;
        param.DbType = DbType.Int32;
        comm.Parameters.Add(param);

        int result = -1;
        try
        {
            // execute command
            result = GenericDataAccess.ExecuteNonQuery(comm);
        }
        catch
        {
            // any errors are logged in GenericDataAccess, ignoer them here

        }
        // result will be 1 in case of success

        return (result != -1);
    }

    // delete Type
    public static bool DeleteType(string id)
    {
        // get a configured Dbcommand object
        DbCommand comm = GenericDataAccess.CreateCommand();

        // Set the stored procedure
        comm.CommandText = "DeleteType";

        //Create a paramenter
        DbParameter param = comm.CreateParameter();
        param.ParameterName = "@TypeID";
        param.Value = id;
        param.DbType = DbType.Int32;
        comm.Parameters.Add(param);

        int result = -1;
        try
        {
            // execute command
            result = GenericDataAccess.ExecuteNonQuery(comm);
        }
        catch
        {
            // any errors are logged in GenericDataAccess, ignoer them here

        }
        // result will be 1 in case of success

        return (result != -1);
    }

    // delete Price
    public static bool DeletePrice(string id)
    {
        // get a configured Dbcommand object
        DbCommand comm = GenericDataAccess.CreateCommand();

        // Set the stored procedure
        comm.CommandText = "DeletePrice";

        //Create a paramenter
        DbParameter param = comm.CreateParameter();
        param.ParameterName = "@PriceID";
        param.Value = id;
        param.DbType = DbType.Int32;
        comm.Parameters.Add(param);

        int result = -1;
        try
        {
            // execute command
            result = GenericDataAccess.ExecuteNonQuery(comm);
        }
        catch
        {
            // any errors are logged in GenericDataAccess, ignoer them here

        }
        // result will be 1 in case of success

        return (result != -1);
    }

    #endregion

    #endregion

    #region GetUsers

    public static UserInfo GetUser(string userID)
    {
        DataTable table = new DataTable();
        DbCommand comm = GenericDataAccess.CreateCommand();
        comm.CommandText = "GetUser";
        DbParameter param = comm.CreateParameter();
        param.ParameterName = "@UserID";
        param.Value = userID;
        param.DbType = DbType.String;
        comm.Parameters.Add(param);

        table = GenericDataAccess.ExecuteSelectCommand(comm);
        UserInfo up = new UserInfo();
        foreach (DataRow userRow in table.Rows)
        {
            up.UserName = userRow["UserName"].ToString();
            up.Email = userRow["Email"].ToString();
            up.Password = userRow["Password"].ToString();
        }

        // return User Info
        return up;
    }

    // Retrieve UserID with productID from ProductHistory
    public static DataTable GetUserLists(string id, string userID)
    {
        DbCommand comm = GenericDataAccess.CreateCommand();
        comm.CommandText = "GetUserListsWithProduct";
        DbParameter param = comm.CreateParameter();
        param.ParameterName = "@ProductID";
        param.Value = id;
        param.DbType = DbType.Int32;
        comm.Parameters.Add(param);
        param = comm.CreateParameter();
        param.ParameterName = "@UserID";
        param.Value = userID;
        param.DbType = DbType.String;
        comm.Parameters.Add(param);

        return GenericDataAccess.ExecuteSelectCommand(comm);
    }

    public static UserInfo GetUserIdByUserName(string username)
    {
        DbCommand comm = GenericDataAccess.CreateCommand();
        comm.CommandText = "GetUserIdByUserName";
        DbParameter param = comm.CreateParameter();
        param.ParameterName = "@UserName";
        param.Value = username;
        param.DbType = DbType.String;
        comm.Parameters.Add(param);

        DataTable table = GenericDataAccess.ExecuteSelectCommand(comm);
        UserInfo user = new UserInfo();
        if (table.Rows.Count > 0)
        {
            user.UserID = table.Rows[0]["UserId"].ToString();
            user.UserName = table.Rows[0]["UserName"].ToString();
        }

        return user;
    }

    #endregion

    #region LoadProductAttribute

    public static void LoadProductAttribute()
    {
        // Store attribute to OCRConfiguration DataTable 
        // As Column 
        // From the database
        LoadBrand();
        LoadYear();
        LoadModel();
        LoadType();
        LoadPrice();
        LoadColor();
        LoadFuel();
        LoadEnginePower();
        LoadHandDrive();
        LoadDoor();
        LoadSeat();
        LoadMilage();
    }

    private static DataTable AddProductIDAndUserID(DataTable table)
    {
        table.Columns.Add("UserID");
        table.Columns.Add("ProductID");
        return table;
    }

    private static void LoadModel()
    {
        DataTable table1 = new DataTable();

        // Add Column ProductID and UserID
        AddProductIDAndUserID(table1);

        // Get data from the database and
        // Store to table as Columns
        DataTable table = GetModel();

        OCRConfiguration.modelDataTable = new DataTable();
        OCRConfiguration.tuprofileModelTable = new DataTable();
        OCRConfiguration.puProfileModelTable = new DataTable();

        foreach (DataRow tableRow in table.Rows)
        {
            OCRConfiguration.modelDataTable.Columns.Add(tableRow["ModelName"].ToString());
            OCRConfiguration.tuprofileModelTable.Columns.Add(tableRow["ModelName"].ToString());
        }

        // Merge DataTable With table1
        OCRConfiguration.modelDataTable.Merge(table1);
        OCRConfiguration.tuprofileModelTable.Merge(table1);
    }

    private static void LoadSeat()
    {
        DataTable table1 = new DataTable();

        // Add Column ProductID and UserID
        AddProductIDAndUserID(table1);

        // Get data from the database and
        // Store to table as Columns
        DataTable table = GetSeat();

        // Add table for profile Table 
        OCRConfiguration.seatDataTable = new DataTable();
        OCRConfiguration.tuprofileSeatDataTable = new DataTable();
        OCRConfiguration.puProfileSeatDataTable = new DataTable();

        foreach (DataRow tableRow in table.Rows)
        {
            OCRConfiguration.seatDataTable.Columns.Add(tableRow["SeatQty"].ToString());
            OCRConfiguration.tuprofileSeatDataTable.Columns.Add(tableRow["SeatQty"].ToString());
        }

        // Merge DataTable With table1
        OCRConfiguration.seatDataTable.Merge(table1);
        OCRConfiguration.tuprofileSeatDataTable.Merge(table1);
    }

    private static void LoadMilage()
    {
        DataTable table1 = new DataTable();

        // Add Column ProductID and UserID
        AddProductIDAndUserID(table1);

        // Get data from the database and
        // Store to table as Columns
        DataTable table = GetMilage();

        // Add table for profile Table 
        OCRConfiguration.milageDataTable = new DataTable();
        OCRConfiguration.tuprofileMilageTable = new DataTable();
        OCRConfiguration.puProfileMilageTable = new DataTable();

        foreach (DataRow tableRow in table.Rows)
        {
            OCRConfiguration.milageDataTable.Columns.Add(tableRow["Milage"].ToString());
            OCRConfiguration.tuprofileMilageTable.Columns.Add(tableRow["Milage"].ToString());
        }

        // Merge DataTable With table1
        OCRConfiguration.milageDataTable.Merge(table1);
        OCRConfiguration.tuprofileMilageTable.Merge(table1);
    }

    private static void LoadHandDrive()
    {
        DataTable table1 = new DataTable();

        // Add Column ProductID and UserID
        AddProductIDAndUserID(table1);

        // Get data from the database and
        // Store to table as Columns
        DataTable table = GetHandDrive();

        // Add table for profile Table 
        OCRConfiguration.handDriveDataTable = new DataTable();
        OCRConfiguration.tuprofileHandDriveTable = new DataTable();
        OCRConfiguration.puProfileHandDriveTable = new DataTable();

        foreach (DataRow tableRow in table.Rows)
        {
            OCRConfiguration.handDriveDataTable.Columns.Add(tableRow["HandDriveName"].ToString());
            OCRConfiguration.tuprofileHandDriveTable.Columns.Add(tableRow["HandDriveName"].ToString());
        }

        // Merge DataTable With table1
        OCRConfiguration.handDriveDataTable.Merge(table1);
        OCRConfiguration.tuprofileHandDriveTable.Merge(table1);
    }

    private static void LoadDoor()
    {
        DataTable table1 = new DataTable();

        // Add Column ProductID and UserID
        AddProductIDAndUserID(table1);

        // Get data from the database and
        // Store to table as Columns
        DataTable table = GetDoors();

        // Add table for profile Table 
        OCRConfiguration.doorDataTable = new DataTable();
        OCRConfiguration.tuprofileDoorTable = new DataTable();
        OCRConfiguration.puProfileDoorTable = new DataTable();

        foreach (DataRow tableRow in table.Rows)
        {
            OCRConfiguration.doorDataTable.Columns.Add(tableRow["DoorQty"].ToString());
            OCRConfiguration.tuprofileDoorTable.Columns.Add(tableRow["DoorQty"].ToString());
        }

        // Merge DataTable With table1
        OCRConfiguration.doorDataTable.Merge(table1);
        OCRConfiguration.tuprofileDoorTable.Merge(table1);
    }

    private static void LoadColor()
    {
        DataTable table1 = new DataTable();

        // Add Column ProductID and UserID
        AddProductIDAndUserID(table1);

        // Get data from the database and
        // Store to table as Columns
        DataTable table = GetColor();

        // Add table for profile Table 
        OCRConfiguration.colorDataTable = new DataTable();
        OCRConfiguration.tuprofileColorTable = new DataTable();
        OCRConfiguration.puProfileColorTable = new DataTable();

        foreach (DataRow tableRow in table.Rows)
        {
            OCRConfiguration.colorDataTable.Columns.Add(tableRow["ColorName"].ToString());
            OCRConfiguration.tuprofileColorTable.Columns.Add(tableRow["ColorName"].ToString());
        }

        // Merge DataTable With table1
        OCRConfiguration.colorDataTable.Merge(table1);
        OCRConfiguration.tuprofileColorTable.Merge(table1);
    }

    private static void LoadEnginePower()
    {
        DataTable table1 = new DataTable();

        // Add Column ProductID and UserID
        AddProductIDAndUserID(table1);

        // Get data from the database and
        // Store to table as Columns
        DataTable table = GetEnginePower();

        // Add table for profile Table 
        OCRConfiguration.engineDataTable = new DataTable();
        OCRConfiguration.tuprofileEngineTable = new DataTable();
        OCRConfiguration.puProfileEngineTable = new DataTable();

        foreach (DataRow tableRow in table.Rows)
        {
            OCRConfiguration.engineDataTable.Columns.Add(tableRow["EngineName"].ToString());
            OCRConfiguration.tuprofileEngineTable.Columns.Add(tableRow["EngineName"].ToString());
        }

        // Merge DataTable With table1
        OCRConfiguration.engineDataTable.Merge(table1);
        OCRConfiguration.tuprofileEngineTable.Merge(table1);
    }

    private static void LoadFuel()
    {
        DataTable table1 = new DataTable();

        // Add Column ProductID and UserID
        AddProductIDAndUserID(table1);

        // Get data from the database and
        // Store to table as Columns
        DataTable table = GetFuel();

        // Add table for profile Table 
        OCRConfiguration.fuelDataTable = new DataTable();
        OCRConfiguration.tuprofileFuelTable = new DataTable();
        OCRConfiguration.puProfileFuelTable = new DataTable();

        foreach (DataRow tableRow in table.Rows)
        {
            OCRConfiguration.fuelDataTable.Columns.Add(tableRow["FuelName"].ToString());
            OCRConfiguration.tuprofileFuelTable.Columns.Add(tableRow["FuelName"].ToString());
        }

        // Merge DataTable With table1
        OCRConfiguration.fuelDataTable.Merge(table1);
        OCRConfiguration.tuprofileFuelTable.Merge(table1);
    }

    private static void LoadPrice()
    {
        DataTable table1 = new DataTable();

        // Add Column ProductID and UserID
        AddProductIDAndUserID(table1);

        // Get data from the database and
        // Store to table as Columns
        DataTable table = GetPrice();

        // Add table for profile Table
        OCRConfiguration.priceDataTable = new DataTable();
        OCRConfiguration.tuprofilePriceTable = new DataTable();
        OCRConfiguration.puProfilePriceTable = new DataTable();

        foreach (DataRow tableRow in table.Rows)
        {
            OCRConfiguration.priceDataTable.Columns.Add(tableRow["Price"].ToString());
            OCRConfiguration.tuprofilePriceTable.Columns.Add(tableRow["Price"].ToString());
        }

        // Merge DataTable With table1
        OCRConfiguration.priceDataTable.Merge(table1);
        OCRConfiguration.tuprofilePriceTable.Merge(table1);
    }

    private static void LoadType()
    {
        DataTable table1 = new DataTable();

        // Add Column ProductID and UserID
        AddProductIDAndUserID(table1);

        // Get data from the database and
        // Store to table as Columns
        DataTable table = GetTypeOfCar();

        // Add table for profile Table
        OCRConfiguration.typeDataTable = new DataTable();
        OCRConfiguration.tuprofileTypeTable = new DataTable();
        OCRConfiguration.puProfileTypeTable = new DataTable();

        foreach (DataRow tableRow in table.Rows)
        {
            OCRConfiguration.typeDataTable.Columns.Add(tableRow["TypeName"].ToString());
            OCRConfiguration.tuprofileTypeTable.Columns.Add(tableRow["TypeName"].ToString());
        }

        // Merge DataTable With table1
        OCRConfiguration.typeDataTable.Merge(table1);
        OCRConfiguration.tuprofileTypeTable.Merge(table1);

    }

    private static void LoadYear()
    {
        DataTable table1 = new DataTable();

        // Add Column ProductID and UserID
        AddProductIDAndUserID(table1);

        // Get data from the database and
        // Store to table as Columns
        DataTable table = GetYear();
        // Add table for profile Table
        OCRConfiguration.tuprofileYearTable = new DataTable();
        OCRConfiguration.puProfileYearTable = new DataTable();
        OCRConfiguration.yearDataTable = new DataTable();
        foreach (DataRow tableRow in table.Rows)
        {
            OCRConfiguration.yearDataTable.Columns.Add(tableRow["Year"].ToString());
            OCRConfiguration.tuprofileYearTable.Columns.Add(tableRow["Year"].ToString());
        }

        // Merge DataTable With table1
        OCRConfiguration.yearDataTable.Merge(table1);
        OCRConfiguration.tuprofileYearTable.Merge(table1);
    }

    private static void LoadBrand()
    {
        DataTable table1 = new DataTable();
        // Add Column ProductID and UserID
        AddProductIDAndUserID(table1);

        // Get data from the database and
        // Store to table as Columns
        DataTable table = GetBrand();
        OCRConfiguration.brandDataTable = new DataTable();
        // Add table for profile Table
        OCRConfiguration.tuprofileBrandTable = new DataTable();
        OCRConfiguration.puProfileBrandTable = new DataTable();

        foreach (DataRow tableRow in table.Rows)
        {
            OCRConfiguration.brandDataTable.Columns.Add(tableRow["BrandName"].ToString());
            OCRConfiguration.tuprofileBrandTable.Columns.Add(tableRow["BrandName"].ToString());
        }

        // Merge DataTable With table1
        OCRConfiguration.brandDataTable.Merge(table1);
        OCRConfiguration.tuprofileBrandTable.Merge(table1);

    }

    #endregion

    #region Create User Profile


    // if equal set 1 and else o
    #region GetAttributeDatafromUserClick and SetUserClickData 1 and 0

    public static void CreateUserClickData(string currentProductID, string userID)
    {

        // Get Product Details with current Product ID 
        ProductDetail details = GetProductDetailsWithProduct(currentProductID);

        //For brand attribute
        GetBrandData(currentProductID, userID, details.brand);

        // For Year Attribute
        GetYearData(currentProductID, userID, details.year);

        // For Model Attribute
        GetModelData(currentProductID, userID, details.model);

        // For Type Attribute
        GetTypeData(currentProductID, userID, details.type);

        // For price Attribute
        GetPriceData(currentProductID, userID, details.Price);

        // For Color Attribute
        GetColorData(currentProductID, userID, details.colorName);

        // For Fuel Attribute
        GetFuelData(currentProductID, userID, details.fuel);

        // For enigine power Attribute
        GetEnginePowerData(currentProductID, userID, details.enginePowerName);

        // For Milage Attribute
        GetMilageData(currentProductID, userID, details.miles);

        // For Door Attribute 
        GetDoorData(currentProductID, userID, details.doorqty);

        // for Seat Attribute
        GetSeatData(currentProductID, userID, details.seatqty);

        // for HandDrive Attribute
        GetHandDriveData(currentProductID, userID, details.handDrive);

    }

    // from User Click History Data
    public static void CreateUserClickData(DataTable historytable, string userID)
    {
        for (int i = 0; i < historytable.Rows.Count; i++)
        {
            string productID = historytable.Rows[i]["ProductID"].ToString();

            CreateUserClickData(productID, userID);
        }
    }

    private static void GetHandDriveData(string currentProductID, string userID, string handDrive)
    {
        //  Get number of column from a table 
        int columnCount = OCRConfiguration.handDriveDataTable.Columns.Count;

        // Create a datarow with table newrow();
        DataRow drHandRow = OCRConfiguration.handDriveDataTable.NewRow();


        for (int i = 0; i < columnCount; i++)
        {
            // check column name of table is equal to user click product attribute
            // if the column is equal 
            // set this column to 1
            // else set 0
            if (OCRConfiguration.handDriveDataTable.Columns[i].ColumnName.ToString() == handDrive)
            {
                drHandRow[i] = 1;
            }
            else
            {
                if (OCRConfiguration.handDriveDataTable.Columns[i].ColumnName.ToString() == "UserID")
                {
                    drHandRow["UserID"] = userID;
                }
                else if (OCRConfiguration.handDriveDataTable.Columns[i].ColumnName.ToString() == "ProductID")
                {
                    drHandRow["ProductID"] = currentProductID;
                }
                else
                {
                    drHandRow[i] = 0;
                }

            }

        }

        // Add row to DataTable
        OCRConfiguration.handDriveDataTable.Rows.Add(drHandRow);
    }

    private static void GetSeatData(string currentProductID, string userID, int p)
    {
        //  Get number of column from a table 
        int columnCount = OCRConfiguration.seatDataTable.Columns.Count;

        // Create a datarow with table newrow();
        DataRow drSeatRow = OCRConfiguration.seatDataTable.NewRow();

        // Convert int to String
        string _seat = Convert.ToString(p);

        for (int i = 0; i < columnCount; i++)
        {
            // check column name of table is equal to user click product attribute
            // if the column is equal 
            // set this column to 1
            // else set 0
            if (OCRConfiguration.seatDataTable.Columns[i].ColumnName.ToString() == _seat)
            {
                drSeatRow[i] = 1;
            }
            else
            {
                if (OCRConfiguration.seatDataTable.Columns[i].ColumnName.ToString() == "UserID")
                {
                    drSeatRow["UserID"] = userID;
                }
                else if (OCRConfiguration.seatDataTable.Columns[i].ColumnName.ToString() == "ProductID")
                {
                    drSeatRow["ProductID"] = currentProductID;
                }
                else
                {
                    drSeatRow[i] = 0;
                }

            }

        }

        // Add row to DataTable
        OCRConfiguration.seatDataTable.Rows.Add(drSeatRow);
    }

    private static void GetDoorData(string currentProductID, string userID, int p)
    {
        //  Get number of column from a table 
        int columnCount = OCRConfiguration.doorDataTable.Columns.Count;

        // Create a datarow with table newrow();
        DataRow drDoorRow = OCRConfiguration.doorDataTable.NewRow();

        // Convert int to String
        string _door = Convert.ToString(p);

        for (int i = 0; i < columnCount; i++)
        {
            // check column name of table is equal to user click product attribute
            // if the column is equal 
            // set this column to 1
            // else set 0
            if (OCRConfiguration.doorDataTable.Columns[i].ColumnName.ToString() == _door)
            {
                drDoorRow[i] = 1;
            }
            else
            {
                if (OCRConfiguration.doorDataTable.Columns[i].ColumnName.ToString() == "UserID")
                {
                    drDoorRow["UserID"] = userID;
                }
                else if (OCRConfiguration.doorDataTable.Columns[i].ColumnName.ToString() == "ProductID")
                {
                    drDoorRow["ProductID"] = currentProductID;
                }
                else
                {
                    drDoorRow[i] = 0;
                }

            }

        }

        // Add row to DataTable
        OCRConfiguration.doorDataTable.Rows.Add(drDoorRow);
    }

    private static void GetMilageData(string currentProductID, string userID, int milage)
    {
        //  Get number of column from a table 
        int columnCount = OCRConfiguration.milageDataTable.Columns.Count;

        // Create a datarow with table newrow();
        DataRow drmilageRow = OCRConfiguration.milageDataTable.NewRow();

        // Convert int to String
        string _milage = Convert.ToString(milage);

        for (int i = 0; i < columnCount; i++)
        {
            // check column name of table is equal to user click product attribute
            // if the column is equal 
            // set this column to 1
            // else set 0
            if (OCRConfiguration.milageDataTable.Columns[i].ColumnName.ToString() == _milage)
            {
                drmilageRow[i] = 1;
            }
            else
            {
                if (OCRConfiguration.milageDataTable.Columns[i].ColumnName.ToString() == "UserID")
                {
                    drmilageRow["UserID"] = userID;
                }
                else if (OCRConfiguration.milageDataTable.Columns[i].ColumnName.ToString() == "ProductID")
                {
                    drmilageRow["ProductID"] = currentProductID;
                }
                else
                {
                    drmilageRow[i] = 0;
                }

            }

        }

        // Add row to DataTable
        OCRConfiguration.milageDataTable.Rows.Add(drmilageRow);
    }

    private static void GetEnginePowerData(string currentProductID, string userID, string enginename)
    {
        //  Get number of column from a table 
        int columnCount = OCRConfiguration.engineDataTable.Columns.Count;

        // Create a datarow with table newrow();
        DataRow drengineRow = OCRConfiguration.engineDataTable.NewRow();

        for (int i = 0; i < columnCount; i++)
        {
            // check column name of table is equal to user click product attribute
            // if the column is equal 
            // set this column to 1
            // else set 0
            if (OCRConfiguration.engineDataTable.Columns[i].ColumnName.ToString() == enginename)
            {
                drengineRow[i] = 1;
            }
            else
            {
                if (OCRConfiguration.engineDataTable.Columns[i].ColumnName.ToString() == "UserID")
                {
                    drengineRow["UserID"] = userID;
                }
                else if (OCRConfiguration.engineDataTable.Columns[i].ColumnName.ToString() == "ProductID")
                {
                    drengineRow["ProductID"] = currentProductID;
                }
                else
                {
                    drengineRow[i] = 0;
                }

            }

        }

        // Add row to DataTable
        OCRConfiguration.engineDataTable.Rows.Add(drengineRow);
    }

    private static void GetFuelData(string currentProductID, string userID, string fuel)
    {
        //  Get number of column from a table 
        int columnCount = OCRConfiguration.fuelDataTable.Columns.Count;

        // Create a datarow with table newrow();
        DataRow drFuelRow = OCRConfiguration.fuelDataTable.NewRow();

        for (int i = 0; i < columnCount; i++)
        {
            // check column name of table is equal to user click product attribute
            // if the column is equal 
            // set this column to 1
            // else set 0
            if (OCRConfiguration.fuelDataTable.Columns[i].ColumnName.ToString() == fuel)
            {
                drFuelRow[i] = 1;
            }
            else
            {
                if (OCRConfiguration.fuelDataTable.Columns[i].ColumnName.ToString() == "UserID")
                {
                    drFuelRow["UserID"] = userID;
                }
                else if (OCRConfiguration.fuelDataTable.Columns[i].ColumnName.ToString() == "ProductID")
                {
                    drFuelRow["ProductID"] = currentProductID;
                }
                else
                {
                    drFuelRow[i] = 0;
                }

            }

        }

        // Add row to DataTable
        OCRConfiguration.fuelDataTable.Rows.Add(drFuelRow);
    }

    private static void GetColorData(string currentProductID, string userID, string color)
    {
        //  Get number of column from a table 
        int columnCount = OCRConfiguration.colorDataTable.Columns.Count;

        // Create a datarow with table newrow();
        DataRow drcolorRow = OCRConfiguration.colorDataTable.NewRow();

        for (int i = 0; i < columnCount; i++)
        {
            // check column name of table is equal to user click product attribute
            // if the column is equal 
            // set this column to 1
            // else set 0
            if (OCRConfiguration.colorDataTable.Columns[i].ColumnName.ToString() == color)
            {
                drcolorRow[i] = 1;
            }
            else
            {
                if (OCRConfiguration.colorDataTable.Columns[i].ColumnName.ToString() == "UserID")
                {
                    drcolorRow["UserID"] = userID;
                }
                else if (OCRConfiguration.colorDataTable.Columns[i].ColumnName.ToString() == "ProductID")
                {
                    drcolorRow["ProductID"] = currentProductID;
                }
                else
                {
                    drcolorRow[i] = 0;
                }

            }

        }

        // Add row to DataTable
        OCRConfiguration.colorDataTable.Rows.Add(drcolorRow);
    }

    private static void GetPriceData(string currentProductID, string userID, decimal price)
    {
        //  Get number of column from a table 
        int columnCount = OCRConfiguration.priceDataTable.Columns.Count;

        // Create a datarow with table newrow();
        DataRow drpriceRow = OCRConfiguration.priceDataTable.NewRow();

        // Convert price to string
        string _price = Convert.ToString(price);

        for (int i = 0; i < columnCount; i++)
        {
            // check column name of table is equal to user click product attribute
            // if the column is equal 
            // set this column to 1
            // else set 0
            if (OCRConfiguration.priceDataTable.Columns[i].ColumnName.ToString() == _price)
            {
                drpriceRow[i] = 1;
            }
            else
            {
                if (OCRConfiguration.priceDataTable.Columns[i].ColumnName.ToString() == "UserID")
                {
                    drpriceRow["UserID"] = userID;
                }
                else if (OCRConfiguration.priceDataTable.Columns[i].ColumnName.ToString() == "ProductID")
                {
                    drpriceRow["ProductID"] = currentProductID;
                }
                else
                {
                    drpriceRow[i] = 0;
                }

            }

        }

        // Add row to DataTable
        OCRConfiguration.priceDataTable.Rows.Add(drpriceRow);
    }

    private static void GetTypeData(string currentProductID, string userID, string typeName)
    {
        //  Get number of column from a table 
        int columnCount = OCRConfiguration.typeDataTable.Columns.Count;

        // Create a datarow with table newrow();
        DataRow drtypeRow = OCRConfiguration.typeDataTable.NewRow();

        for (int i = 0; i < columnCount; i++)
        {
            // check column name of table is equal to user click product attribute
            // if the column is equal 
            // set this column to 1
            // else set 0
            if (OCRConfiguration.typeDataTable.Columns[i].ColumnName.ToString() == typeName)
            {
                drtypeRow[i] = 1;
            }
            else
            {
                if (OCRConfiguration.typeDataTable.Columns[i].ColumnName.ToString() == "UserID")
                {
                    drtypeRow["UserID"] = userID;
                }
                else if (OCRConfiguration.typeDataTable.Columns[i].ColumnName.ToString() == "ProductID")
                {
                    drtypeRow["ProductID"] = currentProductID;
                }
                else
                {
                    drtypeRow[i] = 0;
                }

            }

        }

        // Add row to DataTable
        OCRConfiguration.typeDataTable.Rows.Add(drtypeRow);
    }

    private static void GetModelData(string currentProductID, string userID, string modelname)
    {
        //  Get number of column from a table 
        int columnCount = OCRConfiguration.modelDataTable.Columns.Count;

        // Create a datarow with table newrow();
        DataRow drmodelRow = OCRConfiguration.modelDataTable.NewRow();

        for (int i = 0; i < columnCount; i++)
        {
            // check column name of table is equal to user click product attribute
            // if the column is equal 
            // set this column to 1
            // else set 0
            if (OCRConfiguration.modelDataTable.Columns[i].ColumnName.ToString() == modelname)
            {


                drmodelRow[i] = 1;


            }
            else
            {
                if (OCRConfiguration.modelDataTable.Columns[i].ColumnName.ToString() == "UserID")
                {
                    drmodelRow["UserID"] = userID;
                }
                else if (OCRConfiguration.modelDataTable.Columns[i].ColumnName.ToString() == "ProductID")
                {
                    drmodelRow["ProductID"] = currentProductID;
                }
                else
                {
                    drmodelRow[i] = 0;
                }

            }

        }

        // Add row to DataTable
        OCRConfiguration.modelDataTable.Rows.Add(drmodelRow);
    }

    private static void GetYearData(string currentProductID, string userID, string year)
    {
        //  Get number of column from a table 
        int columnCount = OCRConfiguration.yearDataTable.Columns.Count;

        // Create a datarow with table new row();
        DataRow drYearRow = OCRConfiguration.yearDataTable.NewRow();

        for (int i = 0; i < columnCount; i++)
        {
            // check column name of table is equal to user click product attribute
            // if the column is equal 
            // set this column to 1
            // else set 0
            if (OCRConfiguration.yearDataTable.Columns[i].ColumnName.ToString() == year)
            {


                drYearRow[i] = 1;


            }
            else
            {
                if (OCRConfiguration.yearDataTable.Columns[i].ColumnName.ToString() == "UserID")
                {
                    drYearRow["UserID"] = userID;
                }
                else if (OCRConfiguration.yearDataTable.Columns[i].ColumnName.ToString() == "ProductID")
                {
                    drYearRow["ProductID"] = currentProductID;
                }
                else
                {
                    drYearRow[i] = 0;
                }

            }

        }

        // Add row to DataTable
        OCRConfiguration.yearDataTable.Rows.Add(drYearRow);
    }

    private static void GetBrandData(string currentProductID, string userID, string brandname)
    {
        //  Get number of column from a table
        int columnCount = OCRConfiguration.brandDataTable.Columns.Count;

        // Create a datarow with table new row();
        DataRow drBrandRow = OCRConfiguration.brandDataTable.NewRow();

        for (int i = 0; i < columnCount; i++)
        {
            // check column name of table is equal to user click product attribute
            // if the column is equal 
            // set this column to 1
            // else set 0
            if (OCRConfiguration.brandDataTable.Columns[i].ColumnName.ToString() == brandname)
            {

                drBrandRow[i] = 1;

            }
            else
            {
                if (OCRConfiguration.brandDataTable.Columns[i].ColumnName.ToString() == "UserID")
                {
                    drBrandRow["UserID"] = userID;
                }
                else if (OCRConfiguration.brandDataTable.Columns[i].ColumnName.ToString() == "ProductID")
                {
                    drBrandRow["ProductID"] = currentProductID;
                }
                else
                {
                    drBrandRow[i] = 0;
                }


            }

        }

        // Add row to DataTable
        OCRConfiguration.brandDataTable.Rows.Add(drBrandRow);
    }

    #endregion

    #region UserProfile(Product Attribute's values sum/number of product)

    public static void CreateUserProfile(string userID, string loginUserID)
    {
        // Brand Attribute
        CreateBrandProfile(userID, loginUserID);
        // Year Attribute
        CreateYearProfile(userID, loginUserID);
        // Model Attribute
        CreateModelProfile(userID, loginUserID);
        // Type Attribute
        CreateTypeProfile(userID, loginUserID);
        // Price Attribute
        CreatePriceProfile(userID, loginUserID);
        // Color Attribute
        CreateColorProfile(userID, loginUserID);
        // Fuel Attribute
        CreateFuelProfile(userID, loginUserID);
        // Engine Power attribute
        CreateEnginePowerProfile(userID, loginUserID);
        // HandDrive Attribute
        CreateHandDriveProfile(userID, loginUserID);
        // Door Attribute
        CreateDoorProfile(userID, loginUserID);
        // Seat Attribute
        CreateSeatProfile(userID, loginUserID);
        // Milage Attribute
        CreateMilageProfile(userID, loginUserID);
    }

    private static void CreateMilageProfile(string userID, string loginUserID)
    {
        DataTable table = new DataTable();
        int row = 0;

        bool tuIDIsContain = OCRConfiguration.milageDataTable.AsEnumerable().Any(s => s.Field<string>("UserID") == loginUserID);
        if (!string.IsNullOrEmpty(userID))
        {
            #region Select Table For each Neighbors  Users and create their Profile

            DataTable selectTable = new DataTable();
            selectTable.Merge(OCRConfiguration.milageDataTable.Select("UserID='" + userID + "'").CopyToDataTable());

            // Count the number of row  and column in user click product 
            // list datatable 
            row = selectTable.Rows.Count;

            // Create new Table from existing table
            // Call CrateTable Function
            table = CreateTable(selectTable);

            table = SumOfUserClickData(selectTable, table, userID);

            // Create User Profile
            DataTable profileTable = CreateProfile(table, row);
            // check userID is contained in profileTable
            if (OCRConfiguration.mileflag != true)
            {
                OCRConfiguration.puProfileMilageTable.Merge(profileTable);
                OCRConfiguration.mileflag = true;

            }
            else
            {
                bool isContain = OCRConfiguration.puProfileMilageTable.AsEnumerable().Any(s => s.Field<string>("UserID") == userID);

                if (!isContain)
                {
                    OCRConfiguration.puProfileMilageTable.Merge(profileTable);

                }
            }
            #endregion

        }
        else if ((string.IsNullOrEmpty(userID)) && (tuIDIsContain == true))
        {
            #region Select Table for Login User and Create Profile

            DataTable selectTable = new DataTable();
            selectTable.Merge(OCRConfiguration.milageDataTable.Select("UserID='" + loginUserID + "'").CopyToDataTable());
            row = selectTable.Rows.Count;

            // Create new Table from existing table
            // Call CrateTable Function
            table = CreateTable(selectTable);

            table = SumOfUserClickData(selectTable, table, loginUserID);
            // Create User Profile
            DataTable profileTable = CreateProfile(table, row);
            bool isContain = OCRConfiguration.tuprofileMilageTable.AsEnumerable().Any(s => s.Field<string>("UserID") == loginUserID);
            if (!isContain)
            {
                OCRConfiguration.tuprofileMilageTable = profileTable;
            }
            #endregion
        }
    }

    private static void CreateSeatProfile(string userID, string loginUserID)
    {
        DataTable table = new DataTable();
        int row = 0;

        bool tuIDIsContain = OCRConfiguration.seatDataTable.AsEnumerable().Any(s => s.Field<string>("UserID") == loginUserID);
        if (!string.IsNullOrEmpty(userID))
        {
            #region Select Table For each Neighbors  Users and create their Profile

            DataTable selectTable = new DataTable();
            selectTable.Merge(OCRConfiguration.seatDataTable.Select("UserID='" + userID + "'").CopyToDataTable());

            // Count the number of row  and column in user click product 
            // list datatable 
            row = selectTable.Rows.Count;

            // Create new Table from existing table
            // Call CrateTable Function
            table = CreateTable(selectTable);

            table = SumOfUserClickData(selectTable, table, userID);

            // Create User Profile
            DataTable profileTable = CreateProfile(table, row);
            // check userID is contained in profileTable
            if (OCRConfiguration.seatflag != true)
            {
                OCRConfiguration.puProfileSeatDataTable.Merge(profileTable);
                OCRConfiguration.seatflag = true;

            }
            else
            {
                bool isContain = OCRConfiguration.puProfileSeatDataTable.AsEnumerable().Any(s => s.Field<string>("UserID") == userID);

                if (!isContain)
                {
                    OCRConfiguration.puProfileSeatDataTable.Merge(profileTable);

                }
            }
            #endregion

        }
        else if ((string.IsNullOrEmpty(userID)) && (tuIDIsContain == true))
        {
            #region Select Table for Login User and Create Profile

            DataTable selectTable = new DataTable();
            selectTable.Merge(OCRConfiguration.seatDataTable.Select("UserID='" + loginUserID + "'").CopyToDataTable());
            row = selectTable.Rows.Count;

            // Create new Table from existing table
            // Call CrateTable Function
            table = CreateTable(selectTable);

            table = SumOfUserClickData(selectTable, table, loginUserID);
            // Create User Profile
            DataTable profileTable = CreateProfile(table, row);
            bool isContain = OCRConfiguration.tuprofileSeatDataTable.AsEnumerable().Any(s => s.Field<string>("UserID") == loginUserID);
            if (!isContain)
            {
                OCRConfiguration.tuprofileSeatDataTable = profileTable;
            }
            #endregion
        }
    }

    private static void CreateDoorProfile(string userID, string loginUserID)
    {
        DataTable table = new DataTable();
        int row = 0;

        bool tuIDIsContain = OCRConfiguration.doorDataTable.AsEnumerable().Any(s => s.Field<string>("UserID") == loginUserID);
        if (!string.IsNullOrEmpty(userID))
        {
            #region Select Table For each Neighbors  Users and create their Profile

            DataTable selectTable = new DataTable();
            selectTable.Merge(OCRConfiguration.doorDataTable.Select("UserID='" + userID + "'").CopyToDataTable());

            // Count the number of row  and column in user click product 
            // list datatable 
            row = selectTable.Rows.Count;

            // Create new Table from existing table
            // Call CrateTable Function
            table = CreateTable(selectTable);

            table = SumOfUserClickData(selectTable, table, userID);

            // Create User Profile
            DataTable profileTable = CreateProfile(table, row);
            // check userID is contained in profileTable
            if (OCRConfiguration.doorflag != true)
            {
                OCRConfiguration.puProfileDoorTable.Merge(profileTable);
                OCRConfiguration.doorflag = true;

            }
            else
            {
                bool isContain = OCRConfiguration.puProfileDoorTable.AsEnumerable().Any(s => s.Field<string>("UserID") == userID);

                if (!isContain)
                {
                    OCRConfiguration.puProfileDoorTable.Merge(profileTable);

                }
            }
            #endregion

        }
        else if ((string.IsNullOrEmpty(userID)) && (tuIDIsContain == true))
        {
            #region Select Table for Login User and Create Profile

            DataTable selectTable = new DataTable();
            selectTable.Merge(OCRConfiguration.doorDataTable.Select("UserID='" + loginUserID + "'").CopyToDataTable());
            row = selectTable.Rows.Count;

            // Create new Table from existing table
            // Call CrateTable Function
            table = CreateTable(selectTable);

            table = SumOfUserClickData(selectTable, table, loginUserID);
            // Create User Profile
            DataTable profileTable = CreateProfile(table, row);
            bool isContain = OCRConfiguration.tuprofileDoorTable.AsEnumerable().Any(s => s.Field<string>("UserID") == loginUserID);
            if (!isContain)
            {
                OCRConfiguration.tuprofileDoorTable = profileTable;
            }
            #endregion
        }
    }

    private static void CreateHandDriveProfile(string userID, string loginUserID)
    {
        DataTable table = new DataTable();
        int row = 0;

        bool tuIDIsContain = OCRConfiguration.handDriveDataTable.AsEnumerable().Any(s => s.Field<string>("UserID") == loginUserID);
        if (!string.IsNullOrEmpty(userID))
        {
            #region Select Table For each Neighbors  Users and create their Profile

            DataTable selectTable = new DataTable();
            selectTable.Merge(OCRConfiguration.handDriveDataTable.Select("UserID='" + userID + "'").CopyToDataTable());

            // Count the number of row  and column in user click product 
            // list datatable 
            row = selectTable.Rows.Count;

            // Create new Table from existing table
            // Call CrateTable Function
            table = CreateTable(selectTable);

            table = SumOfUserClickData(selectTable, table, userID);

            // Create User Profile
            DataTable profileTable = CreateProfile(table, row);
            // check userID is contained in profileTable
            if (OCRConfiguration.handflag != true)
            {
                OCRConfiguration.puProfileHandDriveTable.Merge(profileTable);
                OCRConfiguration.handflag = true;

            }
            else
            {
                bool isContain = OCRConfiguration.puProfileHandDriveTable.AsEnumerable().Any(s => s.Field<string>("UserID") == userID);

                if (!isContain)
                {
                    OCRConfiguration.puProfileHandDriveTable.Merge(profileTable);

                }
            }
            #endregion

        }
        else if ((string.IsNullOrEmpty(userID)) && (tuIDIsContain == true))
        {
            #region Select Table for Login User and Create Profile

            DataTable selectTable = new DataTable();
            selectTable.Merge(OCRConfiguration.handDriveDataTable.Select("UserID='" + loginUserID + "'").CopyToDataTable());
            row = selectTable.Rows.Count;

            // Create new Table from existing table
            // Call CrateTable Function
            table = CreateTable(selectTable);

            table = SumOfUserClickData(selectTable, table, loginUserID);
            // Create User Profile
            DataTable profileTable = CreateProfile(table, row);
            bool isContain = OCRConfiguration.tuprofileHandDriveTable.AsEnumerable().Any(s => s.Field<string>("UserID") == loginUserID);
            if (!isContain)
            {
                OCRConfiguration.tuprofileHandDriveTable = profileTable;
            }
            #endregion
        }
    }

    private static void CreateEnginePowerProfile(string userID, string loginUserID)
    {
        DataTable table = new DataTable();
        int row = 0;

        bool tuIDIsContain = OCRConfiguration.engineDataTable.AsEnumerable().Any(s => s.Field<string>("UserID") == loginUserID);
        if (!string.IsNullOrEmpty(userID))
        {
            #region Select Table For each Neighbors  Users and create their Profile

            DataTable selectTable = new DataTable();
            selectTable.Merge(OCRConfiguration.engineDataTable.Select("UserID='" + userID + "'").CopyToDataTable());

            // Count the number of row  and column in user click product 
            // list datatable 
            row = selectTable.Rows.Count;

            // Create new Table from existing table
            // Call CrateTable Function
            table = CreateTable(selectTable);

            table = SumOfUserClickData(selectTable, table, userID);

            // Create User Profile
            DataTable profileTable = CreateProfile(table, row);
            // check userID is contained in profileTable
            if (OCRConfiguration.engineflag != true)
            {
                OCRConfiguration.puProfileEngineTable.Merge(profileTable);
                OCRConfiguration.engineflag = true;

            }
            else
            {
                bool isContain = OCRConfiguration.puProfileEngineTable.AsEnumerable().Any(s => s.Field<string>("UserID") == userID);

                if (!isContain)
                {
                    OCRConfiguration.puProfileEngineTable.Merge(profileTable);

                }
            }
            #endregion

        }
        else if ((string.IsNullOrEmpty(userID)) && (tuIDIsContain == true))
        {
            #region Select Table for Login User and Create Profile

            DataTable selectTable = new DataTable();
            selectTable.Merge(OCRConfiguration.engineDataTable.Select("UserID='" + loginUserID + "'").CopyToDataTable());
            row = selectTable.Rows.Count;

            // Create new Table from existing table
            // Call CrateTable Function
            table = CreateTable(selectTable);

            table = SumOfUserClickData(selectTable, table, loginUserID);
            // Create User Profile
            DataTable profileTable = CreateProfile(table, row);
            bool isContain = OCRConfiguration.tuprofileEngineTable.AsEnumerable().Any(s => s.Field<string>("UserID") == loginUserID);
            if (!isContain)
            {
                OCRConfiguration.tuprofileEngineTable = profileTable;
            }
            #endregion
        }
    }

    private static void CreateColorProfile(string userID, string loginUserID)
    {
        DataTable table = new DataTable();
        int row = 0;

        bool tuIDIsContain = OCRConfiguration.colorDataTable.AsEnumerable().Any(s => s.Field<string>("UserID") == loginUserID);
        if (!string.IsNullOrEmpty(userID))
        {
            #region Select Table For each Neighbors  Users and create their Profile

            DataTable selectTable = new DataTable();
            selectTable.Merge(OCRConfiguration.colorDataTable.Select("UserID='" + userID + "'").CopyToDataTable());

            // Count the number of row  and column in user click product 
            // list datatable 
            row = selectTable.Rows.Count;

            // Create new Table from existing table
            // Call CrateTable Function
            table = CreateTable(selectTable);

            table = SumOfUserClickData(selectTable, table, userID);

            // Create User Profile
            DataTable profileTable = CreateProfile(table, row);
            // check userID is contained in profileTable
            if (OCRConfiguration.colorflag != true)
            {
                OCRConfiguration.puProfileColorTable.Merge(profileTable);
                OCRConfiguration.colorflag = true;

            }
            else
            {
                bool isContain = OCRConfiguration.puProfileColorTable.AsEnumerable().Any(s => s.Field<string>("UserID") == userID);

                if (!isContain)
                {
                    OCRConfiguration.puProfileColorTable.Merge(profileTable);

                }
            }
            #endregion

        }
        else if ((string.IsNullOrEmpty(userID)) && (tuIDIsContain == true))
        {
            #region Select Table for Login User and Create Profile

            DataTable selectTable = new DataTable();
            selectTable.Merge(OCRConfiguration.colorDataTable.Select("UserID='" + loginUserID + "'").CopyToDataTable());
            row = selectTable.Rows.Count;

            // Create new Table from existing table
            // Call CrateTable Function
            table = CreateTable(selectTable);

            table = SumOfUserClickData(selectTable, table, loginUserID);
            // Create User Profile
            DataTable profileTable = CreateProfile(table, row);
            bool isContain = OCRConfiguration.tuprofileColorTable.AsEnumerable().Any(s => s.Field<string>("UserID") == loginUserID);
            if (!isContain)
            {
                OCRConfiguration.tuprofileColorTable = profileTable;
            }
            #endregion
        }
    }

    private static void CreateFuelProfile(string userID, string loginUserID)
    {
        DataTable table = new DataTable();
        int row = 0;

        bool tuIDIsContain = OCRConfiguration.fuelDataTable.AsEnumerable().Any(s => s.Field<string>("UserID") == loginUserID);
        if (!string.IsNullOrEmpty(userID))
        {
            #region Select Table For each Neighbors  Users and create their Profile

            DataTable selectTable = new DataTable();
            selectTable.Merge(OCRConfiguration.fuelDataTable.Select("UserID='" + userID + "'").CopyToDataTable());

            // Count the number of row  and column in user click product 
            // list datatable 
            row = selectTable.Rows.Count;

            // Create new Table from existing table
            // Call CrateTable Function
            table = CreateTable(selectTable);

            table = SumOfUserClickData(selectTable, table, userID);

            // Create User Profile
            DataTable profileTable = CreateProfile(table, row);
            // check userID is contained in profileTable
            if (OCRConfiguration.fuelflag != true)
            {
                OCRConfiguration.puProfileFuelTable.Merge(profileTable);
                OCRConfiguration.fuelflag = true;

            }
            else
            {
                bool isContain = OCRConfiguration.puProfileFuelTable.AsEnumerable().Any(s => s.Field<string>("UserID") == userID);

                if (!isContain)
                {
                    OCRConfiguration.puProfileFuelTable.Merge(profileTable);

                }
            }
            #endregion

        }
        else if ((string.IsNullOrEmpty(userID)) && (tuIDIsContain == true))
        {
            #region Select Table for Login User and Create Profile

            DataTable selectTable = new DataTable();
            selectTable.Merge(OCRConfiguration.fuelDataTable.Select("UserID='" + loginUserID + "'").CopyToDataTable());
            row = selectTable.Rows.Count;

            // Create new Table from existing table
            // Call CrateTable Function
            table = CreateTable(selectTable);

            table = SumOfUserClickData(selectTable, table, loginUserID);
            // Create User Profile
            DataTable profileTable = CreateProfile(table, row);
            bool isContain = OCRConfiguration.tuprofileFuelTable.AsEnumerable().Any(s => s.Field<string>("UserID") == loginUserID);
            if (!isContain)
            {
                OCRConfiguration.tuprofileFuelTable = profileTable;
            }
            #endregion
        }
    }

    private static void CreatePriceProfile(string userID, string loginUserID)
    {
        DataTable table = new DataTable();
        int row = 0;

        bool tuIDIsContain = OCRConfiguration.priceDataTable.AsEnumerable().Any(s => s.Field<string>("UserID") == loginUserID);
        if (!string.IsNullOrEmpty(userID))
        {
            #region Select Table For each Neighbors  Users and create their Profile

            DataTable selectTable = new DataTable();
            selectTable.Merge(OCRConfiguration.priceDataTable.Select("UserID='" + userID + "'").CopyToDataTable());

            // Count the number of row  and column in user click product 
            // list datatable 
            row = selectTable.Rows.Count;

            // Create new Table from existing table
            // Call CrateTable Function
            table = CreateTable(selectTable);

            table = SumOfUserClickData(selectTable, table, userID);

            // Create User Profile
            DataTable profileTable = CreateProfile(table, row);
            // check userID is contained in profileTable
            if (OCRConfiguration.priceflag != true)
            {
                OCRConfiguration.puProfilePriceTable.Merge(profileTable);
                OCRConfiguration.priceflag = true;

            }
            else
            {
                bool isContain = OCRConfiguration.puProfilePriceTable.AsEnumerable().Any(s => s.Field<string>("UserID") == userID);

                if (!isContain)
                {
                    OCRConfiguration.puProfilePriceTable.Merge(profileTable);

                }
            }
            #endregion

        }
        else if ((string.IsNullOrEmpty(userID)) && (tuIDIsContain == true))
        {
            #region Select Table for Login User and Create Profile

            DataTable selectTable = new DataTable();
            selectTable.Merge(OCRConfiguration.priceDataTable.Select("UserID='" + loginUserID + "'").CopyToDataTable());
            row = selectTable.Rows.Count;

            // Create new Table from existing table
            // Call CrateTable Function
            table = CreateTable(selectTable);

            table = SumOfUserClickData(selectTable, table, loginUserID);
            // Create User Profile
            DataTable profileTable = CreateProfile(table, row);
            bool isContain = OCRConfiguration.tuprofilePriceTable.AsEnumerable().Any(s => s.Field<string>("UserID") == loginUserID);
            if (!isContain)
            {
                OCRConfiguration.tuprofilePriceTable = profileTable;
            }
            #endregion
        }
    }

    private static void CreateTypeProfile(string userID, string loginUserID)
    {
        DataTable table = new DataTable();
        int row = 0;

        bool tuIDIsContain = OCRConfiguration.typeDataTable.AsEnumerable().Any(s => s.Field<string>("UserID") == loginUserID);
        if (!string.IsNullOrEmpty(userID))
        {
            #region Select Table For each Neighbors  Users and create their Profile

            DataTable selectTable = new DataTable();
            selectTable.Merge(OCRConfiguration.typeDataTable.Select("UserID='" + userID + "'").CopyToDataTable());

            // Count the number of row  and column in user click product 
            // list datatable 
            row = selectTable.Rows.Count;

            // Create new Table from existing table
            // Call CrateTable Function
            table = CreateTable(selectTable);

            table = SumOfUserClickData(selectTable, table, userID);

            // Create User Profile
            DataTable profileTable = CreateProfile(table, row);
            // check userID is contained in profileTable
            if (OCRConfiguration.typeflag != true)
            {
                OCRConfiguration.puProfileTypeTable.Merge(profileTable);
                OCRConfiguration.typeflag = true;

            }
            else
            {
                bool isContain = OCRConfiguration.puProfileTypeTable.AsEnumerable().Any(s => s.Field<string>("UserID") == userID);

                if (!isContain)
                {
                    OCRConfiguration.puProfileTypeTable.Merge(profileTable);

                }
            }
            #endregion

        }
        else if ((string.IsNullOrEmpty(userID)) && (tuIDIsContain == true))
        {
            #region Select Table for Login User and Create Profile

            DataTable selectTable = new DataTable();
            selectTable.Merge(OCRConfiguration.typeDataTable.Select("UserID='" + loginUserID + "'").CopyToDataTable());
            row = selectTable.Rows.Count;

            // Create new Table from existing table
            // Call CrateTable Function
            table = CreateTable(selectTable);

            table = SumOfUserClickData(selectTable, table, loginUserID);
            // Create User Profile
            DataTable profileTable = CreateProfile(table, row);
            bool isContain = OCRConfiguration.tuprofileTypeTable.AsEnumerable().Any(s => s.Field<string>("UserID") == loginUserID);
            if (!isContain)
            {
                OCRConfiguration.tuprofileTypeTable = profileTable;
            }
            #endregion
        }
    }

    private static void CreateModelProfile(string userID, string loginUserID)
    {
        DataTable table = new DataTable();
        int row = 0;

        bool tuIDIsContain = OCRConfiguration.modelDataTable.AsEnumerable().Any(s => s.Field<string>("UserID") == loginUserID);
        if (!string.IsNullOrEmpty(userID))
        {
            #region Select Table For each Neighbors  Users and create their Profile

            DataTable selectTable = new DataTable();
            selectTable.Merge(OCRConfiguration.modelDataTable.Select("UserID='" + userID + "'").CopyToDataTable());

            // Count the number of row  and column in user click product 
            // list datatable 
            row = selectTable.Rows.Count;

            // Create new Table from existing table
            // Call CrateTable Function
            table = CreateTable(selectTable);

            table = SumOfUserClickData(selectTable, table, userID);

            // Create User Profile
            DataTable profileTable = CreateProfile(table, row);
            // check userID is contained in profileTable
            if (OCRConfiguration.modelflag != true)
            {
                OCRConfiguration.puProfileModelTable.Merge(profileTable);
                OCRConfiguration.modelflag = true;

            }
            else
            {
                bool isContain = OCRConfiguration.puProfileModelTable.AsEnumerable().Any(s => s.Field<string>("UserID") == userID);

                if (!isContain)
                {
                    OCRConfiguration.puProfileModelTable.Merge(profileTable);

                }
            }
            #endregion

        }
        else if ((string.IsNullOrEmpty(userID)) && (tuIDIsContain == true))
        {
            #region Select Table for Login User and Create Profile

            DataTable selectTable = new DataTable();
            selectTable.Merge(OCRConfiguration.modelDataTable.Select("UserID='" + loginUserID + "'").CopyToDataTable());
            row = selectTable.Rows.Count;

            // Create new Table from existing table
            // Call CrateTable Function
            table = CreateTable(selectTable);

            table = SumOfUserClickData(selectTable, table, loginUserID);
            // Create User Profile
            DataTable profileTable = CreateProfile(table, row);
            bool isContain = OCRConfiguration.tuprofileModelTable.AsEnumerable().Any(s => s.Field<string>("UserID") == loginUserID);
            if (!isContain)
            {
                OCRConfiguration.tuprofileModelTable = profileTable;
            }
            #endregion
        }
    }

    private static void CreateYearProfile(string userID, string loginUserID)
    {
        DataTable table = new DataTable();
        int row = 0;
        //DataTable dtYear = OCRConfiguration.yearDataTable;
        bool tuIDIsContain = OCRConfiguration.yearDataTable.AsEnumerable().Any(s => s.Field<string>("UserID") == loginUserID);
        if (!string.IsNullOrEmpty(userID))
        {
            #region Select Table For each Neighbors  Users and create their Profile

            DataTable selectTable = new DataTable();
            selectTable.Merge(OCRConfiguration.yearDataTable.Select("UserID='" + userID + "'").CopyToDataTable());

            // Count the number of row  and column in user click product 
            // list datatable 
            row = selectTable.Rows.Count;

            // Create new Table from existing table
            // Call CrateTable Function
            table = CreateTable(selectTable);

            table = SumOfUserClickData(selectTable, table, userID);

            // Create User Profile
            DataTable profileTable = CreateProfile(table, row);
            // check userID is contained in profileTable
            if (OCRConfiguration.yearflag != true)
            {
                OCRConfiguration.puProfileYearTable.Merge(profileTable);
                OCRConfiguration.yearflag = true;

            }
            else
            {
                bool isContain = OCRConfiguration.puProfileYearTable.AsEnumerable().Any(s => s.Field<string>("UserID") == userID);

                if (!isContain)
                {
                    OCRConfiguration.puProfileYearTable.Merge(profileTable);

                }
            }
            #endregion

        }
        else if ((string.IsNullOrEmpty(userID)) && (tuIDIsContain == true))
        {
            #region Select Table for Login User and Create Profile

            DataTable selectTable = new DataTable();
            selectTable.Merge(OCRConfiguration.yearDataTable.Select("UserID='" + loginUserID + "'").CopyToDataTable());
            row = selectTable.Rows.Count;

            // Create new Table from existing table
            // Call CrateTable Function
            table = CreateTable(selectTable);

            table = SumOfUserClickData(selectTable, table, loginUserID);
            // Create User Profile
            DataTable profileTable = CreateProfile(table, row);
            bool isContain = OCRConfiguration.tuprofileYearTable.AsEnumerable().Any(s => s.Field<string>("UserID") == loginUserID);
            if (!isContain)
            {
                OCRConfiguration.tuprofileYearTable = profileTable;
            }
            #endregion
        }
    }

    private static void CreateBrandProfile(string userID, string loginUserID)
    {
        DataTable table = new DataTable();
        int row = 0;
        //DataTable dtBrand = OCRConfiguration.brandDataTable;
        bool tuIDIsContain = OCRConfiguration.brandDataTable.AsEnumerable().Any(s => s.Field<string>("UserID") == loginUserID);
        if (!string.IsNullOrEmpty(userID))
        {
            #region Select Table For each Neighbors  Users and create their Profile
            DataTable selectTable = new DataTable();
            selectTable.Merge(OCRConfiguration.brandDataTable.Select("UserID='" + userID + "'").CopyToDataTable());
            // Count the number of row  and column in user click product 
            // list datatable 
            row = selectTable.Rows.Count;

            // Create new Table from existing table
            // Call CrateTable Function
            table = CreateTable(selectTable);

            table = SumOfUserClickData(selectTable, table, userID);

            // Create User Profile
            DataTable profileTable = CreateProfile(table, row);
            // check userID is contained in profileTable
            if (OCRConfiguration.brandflag != true)
            {
                OCRConfiguration.puProfileBrandTable.Merge(profileTable);
                OCRConfiguration.brandflag = true;

            }
            else
            {
                bool isContain = OCRConfiguration.puProfileBrandTable.AsEnumerable().Any(s => s.Field<string>("UserID") == userID);

                if (!isContain)
                {
                    OCRConfiguration.puProfileBrandTable.Merge(profileTable);

                }
            }
            #endregion

        }
        else if ((string.IsNullOrEmpty(userID)) && (tuIDIsContain == true))
        {
            #region Select Table for Login User and Create Profile
            DataTable selectTable = new DataTable();
            selectTable.Merge(OCRConfiguration.brandDataTable.Select("UserID='" + loginUserID + "'").CopyToDataTable());
            row = selectTable.Rows.Count;

            // Create new Table from existing table
            // Call CrateTable Function
            table = CreateTable(selectTable);

            table = SumOfUserClickData(selectTable, table, loginUserID);
            // Create User Profile
            DataTable profileTable = CreateProfile(table, row);
            bool isContain = OCRConfiguration.tuprofileBrandTable.AsEnumerable().Any(s => s.Field<string>("UserID") == loginUserID);
            if (!isContain)
            {
                OCRConfiguration.tuprofileBrandTable = profileTable;
            }
            else
            {
                OCRConfiguration.tuprofileBrandTable = profileTable;
            }
            #endregion
        }

    }

    private static DataTable CreateProfile(DataTable table, int numberOfrow)
    {
        DataTable table1 = table;
        if (numberOfrow != 0)
        {


            if (table.Rows.Count > 0)
            {
                for (int i = 0; i < table.Rows.Count; i++)
                {
                    for (int j = 0; j < table.Columns.Count; j++)
                    {
                        if (table.Columns[j].ToString() == "UserID")
                        {
                            table1.Rows[i][j] = table.Rows[i]["UserID"].ToString();
                        }
                        else if (!string.IsNullOrEmpty(table.Rows[i][j].ToString()))
                        {
                            table1.Rows[i][j] = Math.Round(Convert.ToDouble(Convert.ToDouble(table.Rows[i][j].ToString()) / (double)numberOfrow), 2);
                            //profile[j] = Math.Round(Convert.ToDouble(Convert.ToDouble(table.Rows[i][j].ToString()) / (double)numberOfrow), 2);
                        }
                        else
                        {
                            table1.Rows[i][j] = Math.Round(0.0, 2);
                            //profile[j] = Math.Round(0.0, 2); ;
                        }

                    }
                }

            }

        }
        return table1;

    }

    private static DataTable CreateTable(DataTable dtBrand)
    {
        DataTable table = new DataTable();

        // Add columns to new create table
        for (int i = 0; i < dtBrand.Columns.Count; i++)
        {
            if ((dtBrand.Columns[i].ColumnName.ToString() == "ProductID"))
            {

            }
            else
            {
                table.Columns.Add(dtBrand.Columns[i].ToString());
            }

        }
        return table;
    }

    private static DataTable SumOfUserClickData(DataTable table, DataTable table1, string userID)
    {
        // Count the number of row  and column in user click product 
        // list datatable 
        int row = table.Rows.Count;
        int column = table.Columns.Count;
        int count = 0;
        DataRow table1row = table1.NewRow();

        for (int i = 0; i < column; i++)
        {
            for (int j = 0; j < row; j++)
            {
                if (table.Columns[i].ColumnName.ToString() == "UserID")
                {
                    table1row["UserID"] = userID.ToString();
                }
                else if (table.Columns[i].ColumnName.ToString() == "ProductID")
                {

                }
                else if (table.Rows[j][i].ToString() == "1")
                {
                    if (table.Columns[i].ColumnName.ToString() == table.Columns[i].ColumnName.ToString())
                    {
                        count += 1;
                        table1row[i] = count;
                    }
                }
            }
            count = 0;
        }

        // Add row to Table
        table1.Rows.Add(table1row);

        return table1;
    }

    #endregion

    #endregion

    #region NeighborhoodFormation

    // Get Neighbors and recommend Product Lists
    public static DataTable NeighborFormation(DataTable negihborUserTable, string userID)
    {
        #region Get maximum attribute value from all Attributes
        ProductDetail pd = new ProductDetail();
        // For Brand Neighbor and Max attribute value
        string brand = NeighborFormationForAllAttribute(negihborUserTable, OCRConfiguration.tuprofileBrandTable, OCRConfiguration.puProfileBrandTable, userID);
        pd.brand = brand;
        // For Model Neighbor and max attribute value
        string model = NeighborFormationForAllAttribute(negihborUserTable, OCRConfiguration.tuprofileModelTable, OCRConfiguration.puProfileModelTable, userID);
        pd.model = model;
        // For Year Neighbor and max attribute value
        string year = NeighborFormationForAllAttribute(negihborUserTable, OCRConfiguration.tuprofileYearTable, OCRConfiguration.puProfileYearTable, userID);
        pd.year = year;
        // For Type Neighbor and max attribute value
        string type = NeighborFormationForAllAttribute(negihborUserTable, OCRConfiguration.tuprofileTypeTable, OCRConfiguration.puProfileTypeTable, userID);
        pd.type = type;
        // For Price Neighbor and max attribute value
        string price = NeighborFormationForAllAttribute(negihborUserTable, OCRConfiguration.tuprofilePriceTable, OCRConfiguration.puProfilePriceTable, userID);
        pd.Price = Convert.ToDecimal(price);

        // For Color Neighbor and max attribute value
        string color = NeighborFormationForAllAttribute(negihborUserTable, OCRConfiguration.tuprofileColorTable, OCRConfiguration.puProfileColorTable, userID);
        pd.colorName = color;
        // For Fuel Neighbor and max attribute value
        string fuel = NeighborFormationForAllAttribute(negihborUserTable, OCRConfiguration.tuprofileFuelTable, OCRConfiguration.puProfileFuelTable, userID);
        pd.fuel = fuel;
        // For Engine Power Neighbor and max attribute value
        string engine = NeighborFormationForAllAttribute(negihborUserTable, OCRConfiguration.tuprofileEngineTable, OCRConfiguration.puProfileEngineTable, userID);
        pd.enginePowerName = engine;
        // For Hand Drive Neighbor and max attribute value
        string handDrive = NeighborFormationForAllAttribute(negihborUserTable, OCRConfiguration.tuprofileHandDriveTable, OCRConfiguration.puProfileHandDriveTable, userID);
        pd.handDrive = handDrive;
        // For Milage Neighbor and max attribute value
        string milage = NeighborFormationForAllAttribute(negihborUserTable, OCRConfiguration.tuprofileMilageTable, OCRConfiguration.puProfileMilageTable, userID);
        pd.miles = Convert.ToInt32(milage);
        // For Door Neighbor and max attribute value
        string door = NeighborFormationForAllAttribute(negihborUserTable, OCRConfiguration.tuprofileDoorTable, OCRConfiguration.puProfileDoorTable, userID);
        pd.doorqty = Convert.ToInt32(door);
        string seat = NeighborFormationForAllAttribute(negihborUserTable, OCRConfiguration.tuprofileSeatDataTable, OCRConfiguration.puProfileSeatDataTable, userID);
        pd.seatqty = Convert.ToInt32(seat);
        #endregion

        #region Create DbObject And Add Parameters

        DbCommand comm = GenericDataAccess.CreateCommand();
        comm.CommandText = "GetRecommendationProducts";
        DbParameter param = comm.CreateParameter();
        param.ParameterName = "@Brand";
        param.Value = brand;
        param.DbType = DbType.String;
        comm.Parameters.Add(param);

        // Create parameter for year       
        param = comm.CreateParameter();
        param.ParameterName = "@Year";
        param.Value = year;
        param.DbType = DbType.String;
        comm.Parameters.Add(param);

        // Create parameter for Model       
        param = comm.CreateParameter();
        param.ParameterName = "@Model";
        param.Value = model;
        param.DbType = DbType.String;
        comm.Parameters.Add(param);

        // Create parameter for Type       
        param = comm.CreateParameter();
        param.ParameterName = "@Type";
        param.Value = type;
        param.DbType = DbType.String;
        comm.Parameters.Add(param);

        // Create parameter for Price       
        param = comm.CreateParameter();
        param.ParameterName = "@Price";
        param.Value = price;
        param.DbType = DbType.Decimal;
        comm.Parameters.Add(param);

        // Create parameter for Color       
        param = comm.CreateParameter();
        param.ParameterName = "@Color";
        param.Value = color;
        param.DbType = DbType.String;
        comm.Parameters.Add(param);

        // Create parameter for Fuel       
        param = comm.CreateParameter();
        param.ParameterName = "@Fuel";
        param.Value = fuel;
        param.DbType = DbType.String;
        comm.Parameters.Add(param);

        // Create parameter for Engine Power       
        param = comm.CreateParameter();
        param.ParameterName = "@EnginePower";
        param.Value = engine;
        param.DbType = DbType.String;
        comm.Parameters.Add(param);

        // Create parameter for HandDrive       
        param = comm.CreateParameter();
        param.ParameterName = "@HandDrive";
        param.Value = handDrive;
        param.DbType = DbType.String;
        comm.Parameters.Add(param);

        // Create parameter for Milage       
        param = comm.CreateParameter();
        param.ParameterName = "@Milage";
        param.Value = milage;
        param.DbType = DbType.Int32;
        comm.Parameters.Add(param);

        // Create parameter for Doors       
        param = comm.CreateParameter();
        param.ParameterName = "@Door";
        param.Value = door;
        param.DbType = DbType.Int32;
        comm.Parameters.Add(param);

        // Create parameter for Seats       
        param = comm.CreateParameter();
        param.ParameterName = "@Seat";
        param.Value = seat;
        param.DbType = DbType.Int32;
        comm.Parameters.Add(param);
        #endregion

        // Execute the command and return DataTable
        DataTable recommendListTable = GenericDataAccess.ExecuteSelectCommand(comm);

        // Find Similar Product to Db with user generated query (aggregated query)
        DataTable finalRecommend = FindSimilarProduct(recommendListTable, pd);
        // Return final Recommend Lists
        return finalRecommend;
    }

    // Get Product Recommendation for product that have no click by users
    public static DataTable RecommendationForOthers(string brand, string year, string model, string type, decimal price, string color, string fuel, string engine, string handrive, int miles, int door, int seat)
    {

        #region Create DbObject And Add Parameters
        ProductDetail pd = new ProductDetail();
        pd.brand = brand;
        pd.year = year;
        pd.model = model;
        pd.type = type;
        pd.Price = price;
        pd.colorName = color;
        pd.fuel = fuel;
        pd.handDrive = handrive;
        pd.enginePowerName = engine;
        pd.miles = miles;
        pd.seatqty = seat;
        pd.doorqty = door;
        DbCommand comm = GenericDataAccess.CreateCommand();
        comm.CommandText = "GetRecommendationProducts";
        DbParameter param = comm.CreateParameter();
        param.ParameterName = "@Brand";
        param.Value = brand;
        param.DbType = DbType.String;
        comm.Parameters.Add(param);

        // Create parameter for year       
        param = comm.CreateParameter();
        param.ParameterName = "@Year";
        param.Value = year;
        param.DbType = DbType.String;
        comm.Parameters.Add(param);

        // Create parameter for Model       
        param = comm.CreateParameter();
        param.ParameterName = "@Model";
        param.Value = model;
        param.DbType = DbType.String;
        comm.Parameters.Add(param);

        // Create parameter for Type       
        param = comm.CreateParameter();
        param.ParameterName = "@Type";
        param.Value = type;
        param.DbType = DbType.String;
        comm.Parameters.Add(param);

        // Create parameter for Price       
        param = comm.CreateParameter();
        param.ParameterName = "@Price";
        param.Value = price;
        param.DbType = DbType.Decimal;
        comm.Parameters.Add(param);

        // Create parameter for Color       
        param = comm.CreateParameter();
        param.ParameterName = "@Color";
        param.Value = color;
        param.DbType = DbType.String;
        comm.Parameters.Add(param);

        // Create parameter for Fuel       
        param = comm.CreateParameter();
        param.ParameterName = "@Fuel";
        param.Value = fuel;
        param.DbType = DbType.String;
        comm.Parameters.Add(param);

        // Create parameter for Engine Power       
        param = comm.CreateParameter();
        param.ParameterName = "@EnginePower";
        param.Value = engine;
        param.DbType = DbType.String;
        comm.Parameters.Add(param);

        // Create parameter for HandDrive       
        param = comm.CreateParameter();
        param.ParameterName = "@HandDrive";
        param.Value = handrive;
        param.DbType = DbType.String;
        comm.Parameters.Add(param);

        // Create parameter for Milage       
        param = comm.CreateParameter();
        param.ParameterName = "@Milage";
        param.Value = miles;
        param.DbType = DbType.Int32;
        comm.Parameters.Add(param);

        // Create parameter for Doors       
        param = comm.CreateParameter();
        param.ParameterName = "@Door";
        param.Value = door;
        param.DbType = DbType.Int32;
        comm.Parameters.Add(param);

        // Create parameter for Seats       
        param = comm.CreateParameter();
        param.ParameterName = "@Seat";
        param.Value = seat;
        param.DbType = DbType.Int32;
        comm.Parameters.Add(param);
        #endregion

        // Execute the command and return DataTable
        DataTable recommendListTable = GenericDataAccess.ExecuteSelectCommand(comm);

        // Find Similar Product to Db with user generated query (aggregated query)
        DataTable finalRecommend = FindSimilarProduct(recommendListTable, pd);
        // Return final Recommend Lists
        return finalRecommend;
    }
    // Find Most top 5 Similar products from recommended product lists
    private static DataTable FindSimilarProduct(DataTable recommendListTable, ProductDetail pd)
    {
        DataTable result = new DataTable();

        foreach (DataRow recommendList in recommendListTable.Rows)
        {
            int mostSimilar = 0;
            string productID = recommendList["ProductID"].ToString();
            if (pd.brand == recommendList["BrandName"].ToString())
            {
                mostSimilar += 1;
            }
            if (pd.year == recommendList["Year"].ToString())
            {
                mostSimilar += 1;
            }
            if (pd.model == recommendList["ModelName"].ToString())
            {
                mostSimilar += 1;
            }
            if (pd.type == recommendList["TypeName"].ToString())
            {
                mostSimilar += 1;
            }
            if (pd.Price.ToString() == recommendList["Price"].ToString())
            {
                mostSimilar += 1;
            }
            if (pd.colorName == recommendList["ColorName"].ToString())
            {
                mostSimilar += 1;
            }
            if (pd.fuel == recommendList["FuelName"].ToString())
            {
                mostSimilar += 1;
            }
            if (pd.enginePowerName == recommendList["EngineName"].ToString())
            {
                mostSimilar += 1;
            }
            if (pd.handDrive == recommendList["HandDriveName"].ToString())
            {
                mostSimilar += 1;
            }
            if (pd.seatqty.ToString() == recommendList["SeatQty"].ToString())
            {
                mostSimilar += 1;
            }
            if (pd.doorqty.ToString() == recommendList["DoorQty"].ToString())
            {
                mostSimilar += 1;
            }
            if (pd.miles.ToString() == recommendList["Milage"].ToString())
            {
                mostSimilar += 1;
            }

            if (mostSimilar >= 7)
            {
                if (result.Rows.Count < 5)
                {
                    result.Merge(recommendListTable.Select("ProductID='" + productID + "'").CopyToDataTable());
                }

            }
            else if (mostSimilar >= 6)
            {
                if (result.Rows.Count < 5)
                {
                    result.Merge(recommendListTable.Select("ProductID='" + productID + "'").CopyToDataTable());
                }
            }
            else if (mostSimilar >= 5)
            {
                if (result.Rows.Count < 5)
                {
                    result.Merge(recommendListTable.Select("ProductID='" + productID + "'").CopyToDataTable());
                }
            }
            else if (mostSimilar >= 4)
            {
                if (result.Rows.Count < 5)
                {
                    result.Merge(recommendListTable.Select("ProductID='" + productID + "'").CopyToDataTable());
                }
            }
            else if (mostSimilar >= 3)
            {
                if (result.Rows.Count < 5)
                {
                    result.Merge(recommendListTable.Select("ProductID='" + productID + "'").CopyToDataTable());
                }
            }
            else if (mostSimilar >= 2)
            {
                if (result.Rows.Count < 5)
                {
                    result.Merge(recommendListTable.Select("ProductID='" + productID + "'").CopyToDataTable());
                }
            }
        }

        return result;
    }

    // Find neighbors for all Attributes of product
    private static string NeighborFormationForAllAttribute(DataTable negihborUserTable, DataTable tuProfile, DataTable puProfile, string userID)
    {
        DataTable neighborUserProfile = new DataTable();
        DataTable tuProfileTable = new DataTable();
        DataTable table = new DataTable();
        DataTable similarityTable = new DataTable();
        string attribute = string.Empty;

        // Select Target User Profile
        if (tuProfile.Rows.Count > 0)
        {
            tuProfileTable.Merge(tuProfile.Select("UserID='" + userID + "'").CopyToDataTable());

            foreach (DataRow dataRow in negihborUserTable.Rows)
            {
                string puUserID = dataRow["UserID"].ToString();
                neighborUserProfile = puProfile.Select("UserID='" + puUserID + "'").CopyToDataTable();

                // Find similarity 
                double similarValue = FindSimilarity(neighborUserProfile, tuProfileTable);

                // Set UserID and Similarity
                table = SetSimilarityTable(puUserID, similarValue);

                // Merge UserID and similarity for neighbor users
                similarityTable.Merge(table);


            }
        }


        // Find Maxium Similarity from neighbor users list
        attribute = FindMaximumnSimilarity(similarityTable, puProfile);

        // Return atrribute value
        return attribute;
    }

    // Find Similarity between targetUserProfile and neighborUserProfile
    private static double FindSimilarity(DataTable neighborUserProfile, DataTable tuProfileTable)
    {
        double avg, square, similarity;
        // Calculate Upper Multiply Value of tuProfile and neighborUserProfile
        avg = CalculateAvgerate(neighborUserProfile, tuProfileTable);

        // Calculate Lower Square value of tuProfile and neighborUserProfile
        square = CalculateSquare(neighborUserProfile, tuProfileTable);

        // Similarity
        similarity = avg / square;

        return similarity;
    }

    // Get maximum similarity from previous users (neighbor users)
    private static String FindMaximumnSimilarity(DataTable similarityTable, DataTable puProfileTable)
    {
        string attributeName = string.Empty;
        if (similarityTable.Rows.Count > 0)
        {
            // Select row with Maximum similarity
            var maxRow = similarityTable.Select("Similarity = MAX(Similarity)");
            DataTable mostSimilarUser = maxRow.CopyToDataTable();
            string mostSimilarID = mostSimilarUser.Rows[0]["UserID"].ToString();

            DataTable neighborUserTable = puProfileTable.Select("UserID='" + mostSimilarID + "'").CopyToDataTable();

            DataTable userTable = ChangeRowsToColumns(neighborUserTable);

            // Select Maximun Attribute 
            var maxAttribute = userTable.Select("Weight = MAX(Weight)");
            DataTable aggregateAttribute = maxAttribute.CopyToDataTable();
            attributeName = aggregateAttribute.Rows[0]["Name"].ToString();
        }

        return attributeName;
    }

    private static DataTable ChangeRowsToColumns(DataTable neighborUserTable)
    {
        DataTable table = new DataTable();
        table.Columns.Add("Name");
        table.Columns.Add("Weight");


        for (int i = 0; i < neighborUserTable.Columns.Count; i++)
        {
            if (neighborUserTable.Columns[i].ToString() == "UserID")
            {

            }
            else
            {
                DataRow dr = table.NewRow();
                dr["Name"] = neighborUserTable.Columns[i].ToString();
                dr["Weight"] = neighborUserTable.Rows[0][i].ToString();
                table.Rows.Add(dr);
            }

        }
        return table;
    }

    private static DataTable SetSimilarityTable(string puUserID, double similarValue)
    {
        DataTable similarityTable = new DataTable();
        // Create columns
        similarityTable.Columns.Add("UserID");
        similarityTable.Columns.Add("Similarity");
        //create new row
        DataRow row = similarityTable.NewRow();

        row["UserID"] = puUserID;
        row["Similarity"] = similarValue;

        similarityTable.Rows.Add(row);
        // return similarityTable
        return similarityTable;
    }

    private static double CalculateSquare(DataTable neighborUserProfile, DataTable tuProfileTable)
    {
        double _squarevalue = 0.0;

        // Calculate square value of tuProfileTable 
        // by calling CalculateSquareValue()
        double tuSquare = CalculateSquareValue(tuProfileTable);

        // Calculate square value of neighborUserProfile 
        // by calling CalculateSquareValue()
        double puSquare = CalculateSquareValue(neighborUserProfile);

        // Get Square Value by Multiply
        _squarevalue = tuSquare * puSquare;
        return _squarevalue;
    }

    private static double CalculateSquareValue(DataTable profileTable)
    {
        double value = 0.0;
        for (int i = 0; i < profileTable.Rows.Count; i++)
        {
            for (int j = 0; j < profileTable.Columns.Count; j++)
            {
                if (profileTable.Columns[j].ToString() == "UserID")
                {

                }
                else
                {
                    double rowValue = Convert.ToDouble(profileTable.Rows[i][j]);
                    value += Math.Pow(rowValue, 2.0);
                }

            }

        }
        return Math.Sqrt(value);
    }

    private static double CalculateAvgerate(DataTable neighborUserProfile, DataTable tuProfileTable)
    {
        double _sum = 0.0;

        for (int i = 0; i < neighborUserProfile.Rows.Count; i++)
        {
            for (int j = 0; j < tuProfileTable.Rows.Count; j++)
            {
                for (int col = 0; col < neighborUserProfile.Columns.Count; col++)
                {
                    if (tuProfileTable.Columns[col].ToString() == "UserID")
                    {

                    }
                    else
                    {
                        _sum += Convert.ToDouble(tuProfileTable.Rows[j][col].ToString()) * Convert.ToDouble(neighborUserProfile.Rows[i][col].ToString());
                    }


                }
            }
        }
        return _sum;
    }

    #endregion

    #region Popular Product Lists

    // Get Popular Product Lists
    public static DataTable GetPopularProductLists()
    {
        DataTable table = GetPopularProductIDFromDB();
        DataTable popularProduct = new DataTable();

        foreach (DataRow row in table.Rows)
        {
            string productID = row["ProductID"].ToString();

            // get product info table with product ID
            DataTable table1 = GetPopularProductInfo(productID);
            popularProduct.Merge(table1);
        }
        // return popular product lists
        return popularProduct;
    }

    // Get Product Details information for each product
    private static DataTable GetPopularProductInfo(string productID)
    {
        DbCommand comm = GenericDataAccess.CreateCommand();
        comm.CommandText = "GetPopularProductInfo";
        DbParameter param = comm.CreateParameter();
        param.ParameterName = "@ProductID";
        param.Value = productID;
        param.DbType = DbType.Int32;
        comm.Parameters.Add(param);
        return GenericDataAccess.ExecuteSelectCommand(comm);
    }

    // Get Top 5 popular products from Product_History(User's Click data)
    private static DataTable GetPopularProductIDFromDB()
    {
        DbCommand comm = GenericDataAccess.CreateCommand();
        comm.CommandText = "GetPopularProductLists";

        return GenericDataAccess.ExecuteSelectCommand(comm);
    }

    #endregion

    #region Search Product Lists

    // Get User Search Product From the database
    public static DataTable GetSearchProductList(string page, out int howManyPages, string brand, string model, string type, string year, decimal price1, decimal price2)
    {
        DbCommand comm = GenericDataAccess.CreateCommand();
        comm.CommandText = "GetSearchProductLists";

        DbParameter param = comm.CreateParameter();
        param = comm.CreateParameter();
        param.ParameterName = "@PageNumber";
        param.Value = page;
        param.DbType = DbType.Int32;
        comm.Parameters.Add(param);

        // Create a parameter
        param = comm.CreateParameter();
        param.ParameterName = "@ProductsPerPage";
        param.Value = OCRConfiguration.ProductsPerPage;
        param.DbType = DbType.Int32;
        comm.Parameters.Add(param);

        // Create a parameter
        param = comm.CreateParameter();
        param.ParameterName = "@HowManyProducts";
        param.Direction = ParameterDirection.Output;
        param.DbType = DbType.Int32;
        comm.Parameters.Add(param);

        // Create a parameter
        param = comm.CreateParameter();
        param.ParameterName = "@DescriptionLength";
        param.Value = OCRConfiguration.ProductDescriptionLength;
        param.DbType = DbType.Int32;
        comm.Parameters.Add(param);

        // Create a parameter
        param = comm.CreateParameter();
        param.ParameterName = "@Brand";
        param.Value = brand;
        param.DbType = DbType.String;
        comm.Parameters.Add(param);


        // Create a parameter
        param = comm.CreateParameter();
        param.ParameterName = "@Model";
        param.Value = model;
        param.DbType = DbType.String;
        comm.Parameters.Add(param);


        // Create a parameter
        param = comm.CreateParameter();
        param.ParameterName = "@Type";
        param.Value = type;
        param.DbType = DbType.String;
        comm.Parameters.Add(param);


        //// Create a parameter
        //param = comm.CreateParameter();
        //param.ParameterName = "@Brand";
        //param.Value = brand;
        //param.DbType = DbType.String;
        //comm.Parameters.Add(param);


        // Create a parameter
        param = comm.CreateParameter();
        param.ParameterName = "@Year";
        param.Value = year;
        param.DbType = DbType.String;
        comm.Parameters.Add(param);


        // Create a parameter
        param = comm.CreateParameter();
        param.ParameterName = "@Price1";
        param.Value = price1;
        param.DbType = DbType.Decimal;
        comm.Parameters.Add(param);


        // Create a parameter
        param = comm.CreateParameter();
        param.ParameterName = "@Price2";
        param.Value = price2;
        param.DbType = DbType.Decimal;
        comm.Parameters.Add(param);


        //execute the stored pro and save the results in a DataTable
        DataTable table = GenericDataAccess.ExecuteSelectCommand(comm);

        // Calculate how many pages of products and set out parameter
        int howManyProducts = Int32.Parse(comm.Parameters["@HowManyProducts"].Value.ToString());

        howManyPages = (int)Math.Ceiling((double)howManyProducts / (double)OCRConfiguration.ProductsPerPage);

        return table;
    }

    #endregion

}
